import { IdCard, FileText, BadgeCheck, LayoutGrid, FileStack } from "lucide-react";

const FLOAT_CARDS = [
  { icon: IdCard, label: "Passport Photo", cls: "top-4 -left-6 animate-float" },
  { icon: FileStack, label: "PDF Tools", cls: "top-1/3 -right-8 animate-float-delay" },
  { icon: BadgeCheck, label: "ID Card", cls: "bottom-20 -left-10 animate-float-slow" },
  { icon: FileText, label: "Resume", cls: "bottom-2 right-2 animate-float" },
  { icon: LayoutGrid, label: "Design Studio", cls: "top-2 right-16 animate-float-delay" },
];

export default function HeroVisual() {
  return (
    <div className="relative w-full aspect-square max-w-lg mx-auto select-none">
      {/* radiating divine light rays behind the motif */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div
          className="w-[130%] h-[130%] animate-rays opacity-25"
          style={{
            background:
              "conic-gradient(from 0deg, transparent 0deg, #F5B942 6deg, transparent 14deg, transparent 60deg, #7C3AED 66deg, transparent 74deg, transparent 120deg, #06B6D4 126deg, transparent 134deg, transparent 200deg, #F5B942 206deg, transparent 214deg)",
          }}
        />
      </div>

      {/* soft glow */}
      <div className="absolute inset-8 rounded-full bg-gradient-to-br from-violet/25 via-transparent to-cyan/20 blur-2xl" />

      {/* abstract gopuram / temple-arch motif */}
      <svg viewBox="0 0 400 400" className="relative w-full h-full gold-glow" aria-hidden="true">
        <defs>
          <linearGradient id="gop1" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FDE68A" />
            <stop offset="100%" stopColor="#D97706" />
          </linearGradient>
          <linearGradient id="gop2" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#7C3AED" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#06B6D4" stopOpacity="0.7" />
          </linearGradient>
          <radialGradient id="haloGrad" cx="50%" cy="38%" r="55%">
            <stop offset="0%" stopColor="#F5B942" stopOpacity="0.55" />
            <stop offset="100%" stopColor="#F5B942" stopOpacity="0" />
          </radialGradient>
        </defs>

        <circle cx="200" cy="150" r="120" fill="url(#haloGrad)" />

        {/* tiered gopuram silhouette, abstract/geometric */}
        <g>
          <polygon points="200,40 220,70 180,70" fill="url(#gop1)" />
          <polygon points="200,60 240,100 160,100" fill="url(#gop1)" />
          <polygon points="200,90 260,135 140,135" fill="url(#gop1)" opacity="0.95" />
          <rect x="130" y="135" width="140" height="14" rx="2" fill="url(#gop1)" opacity="0.9" />
          <path d="M120 230 C120 180 150 149 200 149 C250 149 280 180 280 230 L280 260 L120 260 Z" fill="url(#gop2)" />
          <rect x="150" y="230" width="100" height="90" rx="6" fill="url(#gop2)" opacity="0.85" />
          <rect x="184" y="260" width="32" height="60" rx="3" fill="#0B1020" />
          <rect x="94" y="260" width="212" height="16" rx="3" fill="url(#gop1)" opacity="0.9" />
        </g>

        {/* decorative pillars */}
        <rect x="60" y="180" width="16" height="96" rx="4" fill="url(#gop2)" opacity="0.5" />
        <rect x="324" y="180" width="16" height="96" rx="4" fill="url(#gop2)" opacity="0.5" />
      </svg>

      {/* floating tool cards */}
      {FLOAT_CARDS.map(({ icon: Icon, label, cls }) => (
        <div
          key={label}
          className={`absolute ${cls} glass rounded-xl px-3 py-2 flex items-center gap-2 shadow-xl shadow-black/30`}
        >
          <span className="w-7 h-7 rounded-lg gradient-primary flex items-center justify-center shrink-0">
            <Icon size={14} className="text-white" />
          </span>
          <span className="text-xs font-medium text-fg whitespace-nowrap pr-1">{label}</span>
        </div>
      ))}
    </div>
  );
}
