"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { Search, X, ArrowRight } from "lucide-react";
import { searchTools } from "@/lib/tools-data";
import * as Icons from "lucide-react";

export default function SearchOverlay({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [q, setQ] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const results = useMemo(() => searchTools(q), [q]);

  useEffect(() => {
    if (open) {
      const t = setTimeout(() => inputRef.current?.focus(), 50);
      return () => clearTimeout(t);
    }
    const t2 = setTimeout(() => setQ(""), 0);
    return () => clearTimeout(t2);
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    if (open) window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-start justify-center pt-24 px-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm animate-fade-up" onClick={onClose} />
      <div className="relative w-full max-w-xl glass rounded-2xl shadow-2xl overflow-hidden animate-fade-up">
        <div className="flex items-center gap-3 px-4 py-3 border-b border-white/10">
          <Search size={20} className="text-fg/50 shrink-0" />
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search tools, services, photo makers, PDF tools..."
            className="flex-1 bg-transparent outline-none text-fg placeholder:text-fg/40 text-sm"
          />
          <button onClick={onClose} aria-label="Close search" className="p-1 rounded-lg hover:bg-white/10 text-fg/60">
            <X size={18} />
          </button>
        </div>
        <div className="max-h-96 overflow-y-auto">
          {q && results.length === 0 && (
            <p className="p-6 text-center text-sm text-fg/50">No tools found for &quot;{q}&quot;</p>
          )}
          {results.map((tool) => {
            const Icon = (Icons as unknown as Record<string, Icons.LucideIcon>)[tool.icon] ?? Icons.Wrench;
            return (
              <Link
                key={tool.id}
                href={tool.href}
                onClick={onClose}
                className="flex items-center gap-3 px-4 py-3 hover:bg-white/5 transition-colors group"
              >
                <span className="w-9 h-9 rounded-lg gradient-primary flex items-center justify-center shrink-0">
                  <Icon size={16} className="text-white" />
                </span>
                <span className="flex-1 min-w-0">
                  <span className="block text-sm font-medium text-fg truncate">{tool.name}</span>
                  <span className="block text-xs text-fg/50 truncate">{tool.description}</span>
                </span>
                <ArrowRight size={14} className="text-fg/30 group-hover:text-cyan group-hover:translate-x-0.5 transition-all shrink-0" />
              </Link>
            );
          })}
          {!q && (
            <div className="p-4 flex flex-wrap gap-2">
              {["Passport Photo", "Image to PDF", "PDF Tools", "ID Card Maker", "Resume Maker"].map((s) => (
                <button
                  key={s}
                  onClick={() => setQ(s)}
                  className="px-3 py-1.5 rounded-full text-xs font-medium bg-white/5 hover:bg-white/10 text-fg/70 transition-colors"
                >
                  {s}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
