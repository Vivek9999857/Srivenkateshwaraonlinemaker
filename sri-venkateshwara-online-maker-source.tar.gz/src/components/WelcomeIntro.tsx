"use client";

import { useEffect, useState } from "react";
import { LogoMark } from "./Logo";

export default function WelcomeIntro() {
  const [visible, setVisible] = useState(false);
  const [stage, setStage] = useState(0);

  useEffect(() => {
    const seen = sessionStorage.getItem("svom-intro-seen");
    if (seen) return;
    const t0 = setTimeout(() => setVisible(true), 0);
    const t1 = setTimeout(() => setStage(1), 150);
    const t2 = setTimeout(() => setStage(2), 650);
    const t3 = setTimeout(() => setStage(3), 1100);
    const t4 = setTimeout(() => finish(), 1900);
    return () => [t0, t1, t2, t3, t4].forEach(clearTimeout);
  }, []);

  function finish() {
    sessionStorage.setItem("svom-intro-seen", "1");
    setVisible(false);
  }

  if (!visible) return null;

  return (
    <div
      role="dialog"
      aria-label="Welcome introduction"
      className="fixed inset-0 z-[100] bg-[#05060d] flex items-center justify-center overflow-hidden"
    >
      {/* radiating divine light rays */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-[140vmax] h-[140vmax] animate-rays opacity-20" style={{
          background: "conic-gradient(from 0deg, transparent 0deg, #F5B942 8deg, transparent 16deg, transparent 40deg, #7C3AED 48deg, transparent 56deg, transparent 90deg, #06B6D4 98deg, transparent 106deg, transparent 140deg, #F5B942 148deg, transparent 156deg)"
        }} />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#05060d]/40 to-[#05060d]" />

      <div className="relative flex flex-col items-center gap-5 px-6 text-center">
        <div
          className={`transition-all duration-700 ${stage >= 1 ? "opacity-100 scale-100" : "opacity-0 scale-75"}`}
        >
          <div className="gold-glow">
            <LogoMark size={88} />
          </div>
        </div>
        <div className={`transition-all duration-700 delay-100 ${stage >= 2 ? "opacity-100 translate-y-0" : "opacity-0 translate-y-3"}`}>
          <h1 className="font-[family-name:var(--font-manrope)] font-extrabold text-2xl md:text-4xl tracking-tight text-white">
            SRI VENKATESHWARA
          </h1>
          <h2 className="font-[family-name:var(--font-manrope)] font-bold text-lg md:text-2xl tracking-[0.2em] gradient-text mt-1">
            ONLINE MAKER
          </h2>
        </div>
        <p className={`transition-all duration-700 delay-200 text-sm md:text-base text-white/60 tracking-wide ${stage >= 3 ? "opacity-100" : "opacity-0"}`}>
          Create. Convert. Design. Print.
        </p>
      </div>

      <button
        onClick={finish}
        className="absolute bottom-8 right-8 text-xs font-medium text-white/50 hover:text-white/90 transition-colors px-4 py-2 rounded-full border border-white/15 hover:border-white/30 focus-ring"
      >
        Skip Intro →
      </button>
    </div>
  );
}
