import Link from "next/link";

export function LogoMark({ size = 40 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <defs>
        <linearGradient id="svom-bg" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
          <stop stopColor="#7C3AED" />
          <stop offset="1" stopColor="#4C1D95" />
        </linearGradient>
        <linearGradient id="svom-gold" x1="8" y1="34" x2="40" y2="10" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FDE68A" />
          <stop offset="1" stopColor="#D97706" />
        </linearGradient>
      </defs>
      <rect width="48" height="48" rx="13" fill="url(#svom-bg)" />
      {/* gopuram-inspired tiered silhouette */}
      <path
        d="M24 8L27.5 13H20.5L24 8Z"
        fill="url(#svom-gold)"
      />
      <path
        d="M24 11.5L30 17.5H18L24 11.5Z"
        fill="url(#svom-gold)"
      />
      <path
        d="M15.5 21C15.5 21 18.5 17.5 24 17.5C29.5 17.5 32.5 21 32.5 21V24H15.5V21Z"
        fill="url(#svom-gold)"
      />
      <rect x="17" y="24" width="14" height="12" rx="1" fill="url(#svom-gold)" fillOpacity="0.92" />
      <rect x="21" y="28" width="6" height="8" rx="0.5" fill="#4C1D95" />
      <circle cx="24" cy="12" r="1.4" fill="#06B6D4" />
    </svg>
  );
}

export function Logo({ withText = true, size = 40 }: { withText?: boolean; size?: number }) {
  return (
    <Link href="/" className="flex items-center gap-2.5 group focus-ring rounded-lg" aria-label="Sri Venkateshwara Online Maker — Home">
      <LogoMark size={size} />
      {withText && (
        <span className="flex flex-col leading-tight">
          <span className="font-[family-name:var(--font-manrope)] font-bold text-[15px] tracking-tight text-fg">
            Sri Venkateshwara
          </span>
          <span className="text-[11px] font-medium tracking-[0.18em] text-cyan uppercase -mt-0.5">
            Online Maker
          </span>
        </span>
      )}
    </Link>
  );
}
