import Link from "next/link";
import * as Icons from "lucide-react";
import { ToolDef } from "@/lib/tools-data";
import { ArrowRight, Clock } from "lucide-react";

export default function ToolCard({ tool }: { tool: ToolDef }) {
  const Icon = (Icons as unknown as Record<string, Icons.LucideIcon>)[tool.icon] ?? Icons.Wrench;

  if (tool.status === "planned") {
    return (
      <div
        className="relative flex flex-col gap-3 rounded-2xl glass-light border border-white/10 p-5 opacity-70 cursor-not-allowed select-none"
        title="This tool is planned and not yet available"
      >
        <div className="flex items-start justify-between">
          <span className="w-11 h-11 rounded-xl gradient-primary flex items-center justify-center opacity-60">
            <Icon size={20} className="text-white" />
          </span>
          <span className="flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide text-amber-400/90 bg-amber-400/10 px-2 py-1 rounded-full">
            <Clock size={10} /> Planned
          </span>
        </div>
        <div>
          <h3 className="font-semibold text-fg text-[15px] leading-snug">{tool.name}</h3>
          <p className="text-sm text-fg/55 mt-1 leading-relaxed">{tool.description}</p>
        </div>
      </div>
    );
  }

  return (
    <Link
      href={tool.href}
      className="group relative flex flex-col gap-3 rounded-2xl glass-light border border-white/10 p-5 hover:-translate-y-1 hover:shadow-xl hover:shadow-violet/10 transition-all duration-300"
    >
      <div className="flex items-start justify-between">
        <span className="w-11 h-11 rounded-xl gradient-primary flex items-center justify-center shadow-lg shadow-violet-deep/20">
          <Icon size={20} className="text-white" />
        </span>
        <ArrowRight size={16} className="text-fg/30 group-hover:text-cyan group-hover:translate-x-1 transition-all mt-2.5" />
      </div>
      <div>
        <h3 className="font-semibold text-fg text-[15px] leading-snug">{tool.name}</h3>
        <p className="text-sm text-fg/55 mt-1 leading-relaxed">{tool.description}</p>
      </div>
    </Link>
  );
}
