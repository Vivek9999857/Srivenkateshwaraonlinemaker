import Link from "next/link";
import { LogoMark } from "./Logo";
import { Globe, Share2, Link2, MessageCircle } from "lucide-react";

const COLUMNS: { title: string; links: { label: string; href: string }[] }[] = [
  {
    title: "Tools",
    links: [
      { label: "Passport Photo PDF", href: "/passport-photo-pdf" },
      { label: "PDF Toolkit", href: "/all-tools?cat=pdf" },
      { label: "ID Card Maker", href: "/id-card-maker" },
      { label: "Resume Maker", href: "/resume-maker" },
      { label: "Design Studio", href: "/all-tools?cat=design" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About Us", href: "/about" },
      { label: "Pricing", href: "/pricing" },
      { label: "Cyber Cafe Program", href: "/cyber-cafe" },
      { label: "Contact", href: "/help" },
    ],
  },
  {
    title: "Support",
    links: [
      { label: "Help Center", href: "/help" },
      { label: "Report an Issue", href: "/help#report" },
      { label: "FAQs", href: "/help#faq" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy Policy", href: "/privacy" },
      { label: "Terms of Service", href: "/terms" },
      { label: "Refund Policy", href: "/refund" },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="mt-16 border-t border-white/10 bg-[#080b16] text-fg/80">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-12 grid grid-cols-2 md:grid-cols-6 gap-8">
        <div className="col-span-2">
          <div className="flex items-center gap-2.5 mb-3">
            <LogoMark size={36} />
            <span className="font-[family-name:var(--font-manrope)] font-bold text-fg">Sri Venkateshwara Online Maker</span>
          </div>
          <p className="text-sm text-fg/50 max-w-xs leading-relaxed">
            Your complete digital work &amp; printing studio — photos, PDFs, documents, designs and print tools, built for India.
          </p>
          <div className="flex gap-3 mt-4">
            {[Globe, Share2, Link2, MessageCircle].map((Icon, i) => (
              <a
                key={i}
                href="#"
                aria-label="Social link"
                className="w-9 h-9 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors"
              >
                <Icon size={15} />
              </a>
            ))}
          </div>
        </div>
        {COLUMNS.map((col) => (
          <div key={col.title}>
            <h4 className="text-sm font-semibold text-fg mb-3">{col.title}</h4>
            <ul className="space-y-2">
              {col.links.map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-sm text-fg/50 hover:text-cyan transition-colors">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-white/10 py-5">
        <div className="max-w-7xl mx-auto px-4 md:px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-fg/40">
          <p>© {new Date().getFullYear()} Sri Venkateshwara Online Maker. All rights reserved.</p>
          <p>Files are processed only for the requested task and temporary files are automatically removed according to our retention policy.</p>
        </div>
      </div>
    </footer>
  );
}
