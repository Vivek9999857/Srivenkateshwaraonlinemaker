"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Search, Sun, Moon, User, Menu, X } from "lucide-react";
import { Logo } from "./Logo";
import { useTheme } from "./ThemeProvider";
import SearchOverlay from "./SearchOverlay";

const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "All Tools", href: "/all-tools" },
  { label: "Photo", href: "/all-tools?cat=photo" },
  { label: "PDF", href: "/all-tools?cat=pdf" },
  { label: "Documents", href: "/all-tools?cat=document" },
  { label: "Design", href: "/all-tools?cat=design" },
  { label: "Cyber Cafe", href: "/cyber-cafe" },
  { label: "Pricing", href: "/pricing" },
  { label: "Help", href: "/help" },
];

export default function Navbar() {
  const { theme, toggle } = useTheme();
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <header
        className={`sticky top-0 z-40 transition-all duration-300 ${
          scrolled ? "glass shadow-lg shadow-black/20" : "bg-transparent"
        }`}
      >
        <nav className="max-w-7xl mx-auto flex items-center justify-between gap-4 px-4 md:px-6 h-16">
          <Logo />

          <ul className="hidden lg:flex items-center gap-1">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  className="px-3 py-2 text-sm font-medium text-fg/80 hover:text-fg rounded-lg hover:bg-white/5 transition-colors focus-ring"
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setSearchOpen(true)}
              aria-label="Search"
              className="p-2.5 rounded-xl hover:bg-white/10 text-fg/80 hover:text-fg transition-colors focus-ring"
            >
              <Search size={18} />
            </button>
            <button
              onClick={toggle}
              aria-label="Toggle theme"
              className="p-2.5 rounded-xl hover:bg-white/10 text-fg/80 hover:text-fg transition-colors focus-ring"
            >
              {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <Link
              href="/login"
              className="hidden sm:inline-flex items-center px-4 py-2 rounded-xl text-sm font-semibold gradient-primary text-white hover:opacity-90 transition-opacity shadow-lg shadow-violet-deep/20"
            >
              Login
            </Link>
            <Link
              href="/login"
              aria-label="Profile"
              className="p-2 rounded-xl hover:bg-white/10 text-fg/80 hover:text-fg transition-colors focus-ring sm:hidden"
            >
              <User size={18} />
            </Link>
            <button
              onClick={() => setMobileOpen((v) => !v)}
              aria-label="Menu"
              className="lg:hidden p-2.5 rounded-xl hover:bg-white/10 text-fg/80 hover:text-fg transition-colors focus-ring"
            >
              {mobileOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </nav>

        {mobileOpen && (
          <div className="lg:hidden glass border-t border-white/5 px-4 py-3 animate-fade-up">
            <ul className="flex flex-col gap-1">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    className="block px-3 py-2.5 text-sm font-medium text-fg/80 hover:text-fg rounded-lg hover:bg-white/5 transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}
      </header>
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />
    </>
  );
}
