"use client";

import { useCallback, useRef, useState } from "react";
import { UploadCloud, X, AlertTriangle, Loader2, FileCheck2 } from "lucide-react";
import { formatBytes, uid } from "@/lib/utils";

export interface UploadedFile {
  id: string;
  file: File;
  previewUrl?: string;
  status: "pending" | "processing" | "done" | "error";
  error?: string;
  progress: number;
}

interface Props {
  accept?: string[];
  multiple?: boolean;
  maxSizeMB?: number;
  maxFiles?: number;
  label?: string;
  hint?: string;
  onFilesReady: (files: UploadedFile[]) => void;
}

const DEFAULT_ACCEPT = ["image/jpeg", "image/png", "image/webp"];

export default function UploadDropzone({
  accept = DEFAULT_ACCEPT,
  multiple = true,
  maxSizeMB = 25,
  maxFiles = 30,
  label = "Drag & drop files here, or click to browse",
  hint,
  onFilesReady,
}: Props) {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const validate = (file: File): string | null => {
    if (accept.length && !accept.includes(file.type)) {
      return "Unsupported format. Please try another file.";
    }
    if (file.size > maxSizeMB * 1024 * 1024) {
      return `File is too large. Max ${maxSizeMB} MB allowed.`;
    }
    return null;
  };

  const process = useCallback(
    (fileList: FileList | File[]) => {
      const incoming = Array.from(fileList).slice(0, maxFiles);
      const mapped: UploadedFile[] = incoming.map((file) => {
        const error = validate(file);
        return {
          id: uid(),
          file,
          previewUrl: file.type.startsWith("image/") ? URL.createObjectURL(file) : undefined,
          status: error ? "error" : "done",
          error: error ?? undefined,
          progress: 100,
        };
      });
      setFiles((prev) => {
        const next = multiple ? [...prev, ...mapped] : mapped;
        onFilesReady(next.filter((f) => f.status === "done"));
        return next;
      });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [multiple, maxFiles, onFilesReady]
  );

  const remove = (id: string) => {
    setFiles((prev) => {
      const target = prev.find((f) => f.id === id);
      if (target?.previewUrl) URL.revokeObjectURL(target.previewUrl);
      const next = prev.filter((f) => f.id !== id);
      onFilesReady(next.filter((f) => f.status === "done"));
      return next;
    });
  };

  return (
    <div>
      <div
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          if (e.dataTransfer.files?.length) process(e.dataTransfer.files);
        }}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === "Enter" && inputRef.current?.click()}
        className={`relative flex flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed p-8 md:p-10 text-center cursor-pointer transition-all focus-ring ${
          dragOver
            ? "border-cyan bg-cyan/5 scale-[1.01]"
            : "border-white/15 hover:border-violet/50 hover:bg-white/[0.02]"
        }`}
      >
        <span className="w-14 h-14 rounded-2xl gradient-primary flex items-center justify-center">
          <UploadCloud size={26} className="text-white" />
        </span>
        <div>
          <p className="font-semibold text-fg">{label}</p>
          {hint && <p className="text-sm text-fg/50 mt-1">{hint}</p>}
          <p className="text-xs text-fg/40 mt-1">
            Max {maxSizeMB} MB per file · {accept.map((a) => a.split("/")[1]?.toUpperCase()).join(", ")}
          </p>
        </div>
        <input
          ref={inputRef}
          type="file"
          multiple={multiple}
          accept={accept.join(",")}
          className="hidden"
          onChange={(e) => e.target.files && process(e.target.files)}
        />
      </div>

      {files.length > 0 && (
        <ul className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {files.map((f) => (
            <li key={f.id} className="relative group rounded-xl overflow-hidden glass-light border border-white/10 p-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  remove(f.id);
                }}
                aria-label="Remove file"
                className="absolute top-1.5 right-1.5 z-10 w-6 h-6 rounded-full bg-black/60 hover:bg-red-500 text-white flex items-center justify-center transition-colors"
              >
                <X size={13} />
              </button>
              <div className="aspect-square rounded-lg overflow-hidden bg-black/20 flex items-center justify-center">
                {f.previewUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={f.previewUrl} alt={f.file.name} className="w-full h-full object-cover" />
                ) : (
                  <FileCheck2 className="text-fg/40" />
                )}
              </div>
              <p className="text-[11px] mt-1.5 truncate text-fg/70">{f.file.name}</p>
              <p className="text-[10px] text-fg/40">{formatBytes(f.file.size)}</p>
              {f.status === "error" && (
                <p className="mt-1 flex items-center gap-1 text-[10px] text-red-400">
                  <AlertTriangle size={11} /> {f.error}
                </p>
              )}
              {f.status === "processing" && (
                <p className="mt-1 flex items-center gap-1 text-[10px] text-cyan">
                  <Loader2 size={11} className="animate-spin" /> Processing...
                </p>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
