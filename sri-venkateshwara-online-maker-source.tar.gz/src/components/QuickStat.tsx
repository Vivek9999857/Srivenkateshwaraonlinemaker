import { LucideIcon } from "lucide-react";

export default function FeatureCard({
  icon: Icon,
  title,
  description,
}: {
  icon: LucideIcon;
  title: string;
  description: string;
}) {
  return (
    <div className="rounded-2xl glass-light p-6 hover:-translate-y-1 transition-transform duration-300 border border-white/10">
      <span className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center mb-4">
        <Icon size={22} className="text-white" />
      </span>
      <h3 className="font-semibold text-fg mb-1.5">{title}</h3>
      <p className="text-sm text-fg/60 leading-relaxed">{description}</p>
    </div>
  );
}
