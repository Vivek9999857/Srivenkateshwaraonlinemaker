"use client";

import { Suspense, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { TOOLS, CATEGORY_LABELS, ToolDef } from "@/lib/tools-data";
import ToolCard from "@/components/ToolCard";
import { Search } from "lucide-react";

const CATS = Object.keys(CATEGORY_LABELS) as ToolDef["category"][];

function AllToolsInner() {
  const params = useSearchParams();
  const initialCat = (params.get("cat") as ToolDef["category"]) || "all";
  const [cat, setCat] = useState<ToolDef["category"] | "all">(initialCat);
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    return TOOLS.filter((t) => {
      const matchesCat = cat === "all" || t.category === cat;
      const matchesQ = !q || t.name.toLowerCase().includes(q.toLowerCase()) || t.description.toLowerCase().includes(q.toLowerCase());
      return matchesCat && matchesQ;
    });
  }, [cat, q]);

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-10">
      <div className="mb-8 text-center">
        <h1 className="font-[family-name:var(--font-manrope)] text-3xl md:text-4xl font-bold text-fg">All Tools</h1>
        <p className="text-fg/60 mt-2">Every photo, PDF, document, ID card and design tool in one directory.</p>
      </div>

      <div className="max-w-xl mx-auto mb-6 relative">
        <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-fg/40" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search tools..."
          className="w-full glass-light border border-white/10 rounded-2xl pl-11 pr-4 py-3 text-fg placeholder:text-fg/40 focus-ring"
        />
      </div>

      <div className="flex flex-wrap justify-center gap-2 mb-10">
        <button
          onClick={() => setCat("all")}
          className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${cat === "all" ? "gradient-primary text-white" : "bg-white/5 hover:bg-white/10 text-fg/70"}`}
        >
          All ({TOOLS.length})
        </button>
        {CATS.map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${cat === c ? "gradient-primary text-white" : "bg-white/5 hover:bg-white/10 text-fg/70"}`}
          >
            {CATEGORY_LABELS[c]} ({TOOLS.filter((t) => t.category === c).length})
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <p className="text-center text-fg/50 py-16">No tools match your search. Try a different keyword.</p>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((t) => (
            <ToolCard key={t.id} tool={t} />
          ))}
        </div>
      )}
    </div>
  );
}

export default function AllToolsPage() {
  return (
    <Suspense fallback={<div className="max-w-7xl mx-auto px-4 py-20 text-center text-fg/50">Loading tools...</div>}>
      <AllToolsInner />
    </Suspense>
  );
}
