"use client";

import { useEffect, useState } from "react";
import { Plus, Trash2, RefreshCcw, Download, Printer, Search, X } from "lucide-react";
import { uid } from "@/lib/utils";

type JobStatus = "pending" | "ready" | "completed" | "failed";
type JobType = "Passport Photo" | "ID Card" | "PDF" | "Photo Print" | "Poster" | "Other";

interface Job {
  id: string;
  token: string;
  customerName: string;
  jobType: JobType;
  detail: string;
  copies: number;
  paymentStatus: "paid" | "unpaid";
  status: JobStatus;
  createdAt: number;
}

const STORAGE_KEY = "svom-cybercafe-queue";

const STATUS_STYLES: Record<JobStatus, string> = {
  pending: "bg-amber-500/15 text-amber-400",
  ready: "bg-cyan/15 text-cyan",
  completed: "bg-emerald-500/15 text-emerald-400",
  failed: "bg-red-500/15 text-red-400",
};

export default function CyberCafePage() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [filter, setFilter] = useState<JobStatus | "all">("all");
  const [q, setQ] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const [form, setForm] = useState({ customerName: "", jobType: "Passport Photo" as JobType, detail: "", copies: 1, paymentStatus: "unpaid" as "paid" | "unpaid" });

  const demoJobs: Job[] = [
    { id: "demo-1", token: "#001", customerName: "Ramesh Kumar", jobType: "Passport Photo", detail: "8 copies · A4 sheet", copies: 8, paymentStatus: "paid", status: "ready", createdAt: 0 },
    { id: "demo-2", token: "#002", customerName: "Priya Sharma", jobType: "ID Card", detail: "2 cards · College ID", copies: 2, paymentStatus: "unpaid", status: "pending", createdAt: 0 },
    { id: "demo-3", token: "#003", customerName: "Anil Traders", jobType: "PDF", detail: "14 pages · Merged", copies: 1, paymentStatus: "paid", status: "completed", createdAt: 0 },
  ];

  useEffect(() => {
    const t = setTimeout(() => {
      try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) setJobs(JSON.parse(saved));
        else setJobs(demoJobs);
      } catch {
        setJobs(demoJobs);
      }
    }, 0);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (jobs.length) localStorage.setItem(STORAGE_KEY, JSON.stringify(jobs));
  }, [jobs]);



  function notify(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  }

  function addJob() {
    if (!form.customerName.trim()) return notify("Please enter customer name.");
    const token = `#${String(jobs.length + 1).padStart(3, "0")}`;
    setJobs((prev) => [
      { id: uid(), token, customerName: form.customerName, jobType: form.jobType, detail: form.detail || `${form.copies} copies`, copies: form.copies, paymentStatus: form.paymentStatus, status: "pending", createdAt: Date.now() },
      ...prev,
    ]);
    setForm({ customerName: "", jobType: "Passport Photo", detail: "", copies: 1, paymentStatus: "unpaid" });
    setShowForm(false);
    notify("Job added to queue.");
  }

  function setStatus(id: string, status: JobStatus) {
    setJobs((prev) => prev.map((j) => (j.id === id ? { ...j, status } : j)));
  }
  function removeJob(id: string) {
    setJobs((prev) => prev.filter((j) => j.id !== id));
    notify("Customer data deleted.");
  }

  const filtered = jobs.filter((j) => (filter === "all" || j.status === filter) && (!q || j.customerName.toLowerCase().includes(q.toLowerCase()) || j.token.includes(q)));

  const counts = {
    pending: jobs.filter((j) => j.status === "pending").length,
    ready: jobs.filter((j) => j.status === "ready").length,
    completed: jobs.filter((j) => j.status === "completed").length,
    failed: jobs.filter((j) => j.status === "failed").length,
  };

  return (
    <div className="max-w-6xl mx-auto px-4 md:px-6 py-8 md:py-10">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <h1 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">Cyber Cafe Workspace</h1>
          <p className="text-fg/60 mt-1">Manage every customer&apos;s job in one fast queue — built for shop operators.</p>
        </div>
        <button onClick={() => setShowForm(true)} className="inline-flex items-center gap-2 px-5 py-3 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity">
          <Plus size={18} /> New Customer Job
        </button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <StatCard label="Pending" value={counts.pending} color="text-amber-400" />
        <StatCard label="Ready" value={counts.ready} color="text-cyan" />
        <StatCard label="Completed" value={counts.completed} color="text-emerald-400" />
        <StatCard label="Failed" value={counts.failed} color="text-red-400" />
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-5">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-fg/40" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by customer or token..." className="w-full glass-light border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-sm text-fg focus-ring" />
        </div>
        <div className="flex gap-2 flex-wrap">
          {(["all", "pending", "ready", "completed", "failed"] as const).map((f) => (
            <button key={f} onClick={() => setFilter(f)} className={`px-3.5 py-2 rounded-xl text-xs font-semibold capitalize transition-colors ${filter === f ? "gradient-primary text-white" : "bg-white/5 hover:bg-white/10 text-fg/70"}`}>
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        {filtered.length === 0 ? (
          <p className="text-center text-fg/50 py-16">No jobs in this view.</p>
        ) : (
          filtered.map((j) => (
            <div key={j.id} className="glass-light rounded-2xl border border-white/10 p-4 flex flex-col sm:flex-row sm:items-center gap-3">
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <span className="w-11 h-11 rounded-xl gradient-primary text-white font-bold flex items-center justify-center text-sm shrink-0">{j.token}</span>
                <div className="min-w-0">
                  <p className="font-semibold text-fg truncate">{j.customerName} · {j.jobType}</p>
                  <p className="text-xs text-fg/50 truncate">{j.detail} · <span className={j.paymentStatus === "paid" ? "text-emerald-400" : "text-amber-400"}>{j.paymentStatus === "paid" ? "Paid" : "Payment Pending"}</span></p>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className={`text-xs font-semibold px-3 py-1.5 rounded-full capitalize ${STATUS_STYLES[j.status]}`}>{j.status}</span>
                <select value={j.status} onChange={(e) => setStatus(j.id, e.target.value as JobStatus)} className="bg-transparent border border-white/15 rounded-lg px-2 py-1.5 text-xs text-fg">
                  <option value="pending" className="bg-surface">Pending</option>
                  <option value="ready" className="bg-surface">Ready</option>
                  <option value="completed" className="bg-surface">Completed</option>
                  <option value="failed" className="bg-surface">Failed</option>
                </select>
                <button onClick={() => notify("Reprint job sent to printer.")} title="Reprint" className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-fg/60"><Printer size={14} /></button>
                <button onClick={() => notify("File downloaded again.")} title="Download again" className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-fg/60"><Download size={14} /></button>
                <button onClick={() => removeJob(j.id)} title="Delete customer data" className="p-2 rounded-lg bg-white/5 hover:bg-red-500/15 text-fg/60 hover:text-red-400"><Trash2 size={14} /></button>
              </div>
            </div>
          ))
        )}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setShowForm(false)} />
          <div className="relative glass rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-fg">New Customer Job</h3>
              <button onClick={() => setShowForm(false)}><X size={18} className="text-fg/50" /></button>
            </div>
            <div className="space-y-3">
              <Field label="Customer Name" value={form.customerName} onChange={(v) => setForm((f) => ({ ...f, customerName: v }))} />
              <label className="text-xs text-fg/50 block">Job Type
                <select value={form.jobType} onChange={(e) => setForm((f) => ({ ...f, jobType: e.target.value as JobType }))} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-3 py-2 text-fg">
                  {["Passport Photo", "ID Card", "PDF", "Photo Print", "Poster", "Other"].map((t) => <option key={t} value={t} className="bg-surface">{t}</option>)}
                </select>
              </label>
              <Field label="Detail (e.g. 8 copies, A4)" value={form.detail} onChange={(v) => setForm((f) => ({ ...f, detail: v }))} />
              <label className="text-xs text-fg/50 block">Copies
                <input type="number" min={1} value={form.copies} onChange={(e) => setForm((f) => ({ ...f, copies: +e.target.value }))} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-3 py-2 text-fg" />
              </label>
              <label className="text-xs text-fg/50 block">Payment
                <select value={form.paymentStatus} onChange={(e) => setForm((f) => ({ ...f, paymentStatus: e.target.value as never }))} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-3 py-2 text-fg">
                  <option value="unpaid" className="bg-surface">Unpaid</option>
                  <option value="paid" className="bg-surface">Paid</option>
                </select>
              </label>
              <button onClick={addJob} className="w-full mt-2 py-3 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity">
                Add to Queue
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 glass px-5 py-3 rounded-xl shadow-xl text-sm text-fg flex items-center gap-2 animate-fade-up">
          <RefreshCcw size={14} /> {toast}
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="glass-light rounded-xl border border-white/10 p-4 text-center">
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
      <p className="text-xs text-fg/50 mt-0.5">{label}</p>
    </div>
  );
}
function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="text-xs text-fg/50 block">
      {label}
      <input value={value} onChange={(e) => onChange(e.target.value)} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-3 py-2 text-fg text-sm" />
    </label>
  );
}
