"use client";

import { useRef, useState } from "react";
import { jsPDF } from "jspdf";
import { UploadCloud, Camera, Trash2, Download, X, Sun, Contrast as ContrastIcon, Palette } from "lucide-react";
import { fileToDataUrl, loadImage } from "@/lib/image-ops";
import { uid } from "@/lib/utils";

interface ScanPage {
  id: string;
  original: string;
  processed: string;
  brightness: number;
  contrast: number;
  mode: "color" | "grayscale" | "bw";
}

export default function DocumentScannerPage() {
  const [pages, setPages] = useState<ScanPage[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);

  function notify(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  }

  async function handleFiles(files: FileList) {
    for (const f of Array.from(files)) {
      if (!["image/jpeg", "image/png", "image/webp"].includes(f.type)) { notify(`Unsupported format: ${f.name}`); continue; }
      try {
        const dataUrl = await fileToDataUrl(f);
        const id = uid();
        setPages((prev) => [...prev, { id, original: dataUrl, processed: dataUrl, brightness: 0, contrast: 10, mode: "color" }]);
        setActiveId(id);
      } catch {
        notify(`Unable to process this image: ${f.name}`);
      }
    }
  }

  async function reprocess(id: string, patch: Partial<ScanPage>) {
    setPages((prev) => prev.map((p) => (p.id === id ? { ...p, ...patch } : p)));
    const page = pages.find((p) => p.id === id);
    if (!page) return;
    const merged = { ...page, ...patch };
    try {
      const img = await loadImage(merged.original);
      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext("2d")!;
      let filter = `brightness(${100 + merged.brightness}%) contrast(${100 + merged.contrast}%)`;
      if (merged.mode === "grayscale") filter += " grayscale(100%)";
      if (merged.mode === "bw") filter += " grayscale(100%) contrast(200%)";
      ctx.filter = filter;
      ctx.drawImage(img, 0, 0);
      const processed = canvas.toDataURL("image/jpeg", 0.92);
      setPages((prev) => prev.map((p) => (p.id === id ? { ...p, ...patch, processed } : p)));
    } catch {
      notify("Unable to process this image.");
    }
  }

  function remove(id: string) {
    setPages((prev) => prev.filter((p) => p.id !== id));
    if (activeId === id) setActiveId(null);
  }

  function move(id: string, dir: -1 | 1) {
    setPages((prev) => {
      const idx = prev.findIndex((p) => p.id === id);
      const newIdx = idx + dir;
      if (newIdx < 0 || newIdx >= prev.length) return prev;
      const next = [...prev];
      [next[idx], next[newIdx]] = [next[newIdx], next[idx]];
      return next;
    });
  }

  async function generatePdf() {
    if (pages.length === 0) return notify("Scan or upload at least one page first.");
    try {
      const pdf = new jsPDF({ unit: "mm", format: "a4" });
      for (let i = 0; i < pages.length; i++) {
        if (i > 0) pdf.addPage();
        const img = await loadImage(pages[i].processed);
        const pageW = 210, pageH = 297;
        const imgAspect = img.width / img.height;
        const pageAspect = pageW / pageH;
        let w = pageW, h = pageH, x = 0, y = 0;
        if (imgAspect > pageAspect) { h = pageW / imgAspect; y = (pageH - h) / 2; }
        else { w = pageH * imgAspect; x = (pageW - w) / 2; }
        pdf.addImage(pages[i].processed, "JPEG", x, y, w, h);
      }
      pdf.save("scanned-document-sri-venkateshwara.pdf");
      notify("Scanned PDF downloaded successfully.");
    } catch {
      notify("We couldn't generate the PDF. Please try again.");
    }
  }

  const active = pages.find((p) => p.id === activeId);

  return (
    <div className="max-w-5xl mx-auto px-4 md:px-6 py-8 md:py-10">
      <div className="mb-8">
        <h1 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">Document Scanner</h1>
        <p className="text-fg/60 mt-1">Scan documents with your camera or upload photos, enhance them, and combine into a single PDF. Mobile-friendly.</p>
      </div>

      <div className="grid sm:grid-cols-2 gap-3 mb-6">
        <button onClick={() => cameraRef.current?.click()} className="glass-light border border-white/10 rounded-2xl p-6 text-center hover:border-violet/40 transition-colors">
          <Camera className="mx-auto mb-2 text-violet" size={26} />
          <p className="text-sm font-medium text-fg">Use Camera</p>
          <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => e.target.files && handleFiles(e.target.files)} />
        </button>
        <button onClick={() => fileRef.current?.click()} className="glass-light border border-white/10 rounded-2xl p-6 text-center hover:border-violet/40 transition-colors">
          <UploadCloud className="mx-auto mb-2 text-cyan" size={26} />
          <p className="text-sm font-medium text-fg">Upload Photo</p>
          <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={(e) => e.target.files && handleFiles(e.target.files)} />
        </button>
      </div>

      {pages.length > 0 && (
        <div className="grid lg:grid-cols-[1fr_280px] gap-5 mb-6">
          <div className="glass-light rounded-2xl border border-white/10 p-4">
            <h3 className="text-sm font-semibold text-fg mb-3">Pages ({pages.length})</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {pages.map((p, idx) => (
                <div key={p.id} onClick={() => setActiveId(p.id)} className={`relative rounded-xl overflow-hidden border cursor-pointer ${activeId === p.id ? "border-cyan" : "border-white/10"}`}>
                  <span className="absolute top-1 left-1 z-10 w-5 h-5 rounded-full bg-black/70 text-white text-[10px] font-bold flex items-center justify-center">{idx + 1}</span>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={p.processed} alt={`Page ${idx + 1}`} className="w-full aspect-[3/4] object-cover" />
                  <div className="absolute bottom-1 right-1 flex gap-1">
                    <button onClick={(e) => { e.stopPropagation(); move(p.id, -1); }} className="w-5 h-5 rounded bg-black/70 text-white text-[10px]">←</button>
                    <button onClick={(e) => { e.stopPropagation(); move(p.id, 1); }} className="w-5 h-5 rounded bg-black/70 text-white text-[10px]">→</button>
                    <button onClick={(e) => { e.stopPropagation(); remove(p.id); }} className="w-5 h-5 rounded bg-black/70 hover:bg-red-500 text-white flex items-center justify-center"><Trash2 size={10} /></button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {active && (
            <div className="glass-light rounded-2xl border border-white/10 p-4 space-y-4 h-fit">
              <h3 className="text-sm font-semibold text-fg">Enhance Selected Page</h3>
              <div>
                <span className="flex items-center gap-1.5 text-xs text-fg/60 mb-1"><Palette size={13} /> Mode</span>
                <div className="grid grid-cols-3 gap-1.5">
                  {(["color", "grayscale", "bw"] as const).map((m) => (
                    <button key={m} onClick={() => reprocess(active.id, { mode: m })} className={`py-1.5 rounded-lg text-[11px] font-medium capitalize ${active.mode === m ? "gradient-primary text-white" : "bg-white/5 text-fg/60"}`}>
                      {m === "bw" ? "B&W" : m}
                    </button>
                  ))}
                </div>
              </div>
              <label className="block">
                <span className="flex items-center gap-1.5 text-xs text-fg/60 mb-1"><Sun size={13} /> Brightness</span>
                <input type="range" min={-50} max={50} value={active.brightness} onChange={(e) => reprocess(active.id, { brightness: +e.target.value })} className="w-full accent-violet" />
              </label>
              <label className="block">
                <span className="flex items-center gap-1.5 text-xs text-fg/60 mb-1"><ContrastIcon size={13} /> Contrast</span>
                <input type="range" min={-50} max={80} value={active.contrast} onChange={(e) => reprocess(active.id, { contrast: +e.target.value })} className="w-full accent-violet" />
              </label>
            </div>
          )}
        </div>
      )}

      <button onClick={generatePdf} disabled={pages.length === 0} className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity disabled:opacity-50">
        <Download size={18} /> Generate PDF
      </button>

      {toast && (
        <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 glass px-5 py-3 rounded-xl shadow-xl text-sm text-fg flex items-center gap-2 animate-fade-up">
          {toast}
          <button onClick={() => setToast(null)}><X size={14} /></button>
        </div>
      )}
    </div>
  );
}
