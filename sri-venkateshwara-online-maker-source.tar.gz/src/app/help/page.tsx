"use client";

import { useState } from "react";
import { HelpCircle, ChevronRight, LifeBuoy, Send } from "lucide-react";

const TOPICS = [
  { title: "Upload problems", body: "Make sure your file is under the size limit shown on each tool and matches an accepted format (JPG, PNG, WEBP, or PDF where applicable). If a file keeps failing, try re-saving it or using a different browser." },
  { title: "Download problems", body: "If a download does not start, check your browser's pop-up/download blocker. Most tools also offer a manual 'Download' button as a fallback if automatic download is blocked." },
  { title: "Print problems", body: "Always use the 'Print Preview' or 'Actual Size' view before printing to confirm dimensions. Set your printer's paper size to match the sheet size chosen in the tool, and disable 'fit to page' scaling for exact-size prints." },
  { title: "PDF problems", body: "Large PDFs may take longer to process since everything runs in your browser for privacy. If a PDF tool fails, try splitting your file into smaller batches." },
  { title: "Passport photo sizing help", body: "India passport photos are 35×45mm. Use the India preset in the Passport Photo PDF Generator for automatic correct sizing, or enter a custom size if your requirement differs." },
];

const FAQS = [
  { q: "Why do some tools show 'Planned'?", a: "We only mark a tool live once it is fully functional. Tools marked Planned are on our roadmap and will be enabled once ready — we never advertise incomplete features as available." },
  { q: "Is there a mobile app?", a: "Sri Venkateshwara Online Maker is a installable web app (PWA) — you can add it to your home screen from your mobile browser for app-like access." },
  { q: "How do I report a bug?", a: "Use the 'Report Tool Issue' button inside any tool, or the form below." },
];

export default function HelpPage() {
  const [issue, setIssue] = useState("");
  const [sent, setSent] = useState(false);

  return (
    <div className="max-w-4xl mx-auto px-4 md:px-6 py-10 md:py-14">
      <div className="text-center mb-10">
        <LifeBuoy size={36} className="mx-auto text-cyan mb-3" />
        <h1 className="font-[family-name:var(--font-manrope)] text-3xl font-bold text-fg">Help Center</h1>
        <p className="text-fg/60 mt-2">Tutorials, answers and support for every tool on the platform.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4 mb-12">
        {TOPICS.map((t) => (
          <div key={t.title} className="glass-light rounded-2xl border border-white/10 p-5">
            <h3 className="font-semibold text-fg mb-1.5">{t.title}</h3>
            <p className="text-sm text-fg/60 leading-relaxed">{t.body}</p>
          </div>
        ))}
      </div>

      <div id="faq" className="mb-12">
        <h2 className="font-[family-name:var(--font-manrope)] text-xl font-bold text-fg mb-4">Frequently Asked Questions</h2>
        <div className="space-y-3">
          {FAQS.map((f) => (
            <details key={f.q} className="group glass-light rounded-xl border border-white/10 p-5">
              <summary className="flex items-center justify-between cursor-pointer font-medium text-fg list-none">
                <span className="flex items-center gap-2"><HelpCircle size={16} className="text-cyan shrink-0" />{f.q}</span>
                <ChevronRight size={16} className="text-fg/40 group-open:rotate-90 transition-transform shrink-0" />
              </summary>
              <p className="text-sm text-fg/60 mt-3 leading-relaxed pl-6">{f.a}</p>
            </details>
          ))}
        </div>
      </div>

      <div id="report" className="glass-light rounded-2xl border border-white/10 p-6">
        <h2 className="font-semibold text-fg mb-3">Report a Problem</h2>
        {sent ? (
          <p className="text-sm text-emerald-400">Thank you! Your report has been received. Our team will look into it.</p>
        ) : (
          <div className="flex flex-col sm:flex-row gap-3">
            <input value={issue} onChange={(e) => setIssue(e.target.value)} placeholder="Describe the issue you're facing..." className="flex-1 bg-transparent border border-white/15 rounded-xl px-4 py-3 text-fg text-sm focus-ring" />
            <button onClick={() => issue.trim() && setSent(true)} className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity text-sm">
              <Send size={15} /> Submit
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
