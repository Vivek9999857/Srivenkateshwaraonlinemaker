"use client";

import { useCallback, useRef, useState } from "react";
import { jsPDF } from "jspdf";
import { UploadCloud, Trash2, Download, GripVertical, X } from "lucide-react";
import { fileToDataUrl, loadImage } from "@/lib/image-ops";
import { uid, formatBytes } from "@/lib/utils";

interface ImgItem {
  id: string;
  file: File;
  dataUrl: string;
}

const ACCEPT = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
const PAGE_SIZES: Record<string, [number, number]> = {
  a4: [210, 297],
  fit: [0, 0],
  letter: [215.9, 279.4],
};

export default function ImageToPdfPage() {
  const [items, setItems] = useState<ImgItem[]>([]);
  const [pageSize, setPageSize] = useState("a4");
  const [processing, setProcessing] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [dragIdx, setDragIdx] = useState<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  function notify(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  }

  const handleFiles = useCallback(async (files: FileList | File[]) => {
    const list = Array.from(files);
    const next: ImgItem[] = [];
    for (const file of list) {
      if (!ACCEPT.includes(file.type)) { notify(`Unsupported format: ${file.name}`); continue; }
      if (file.size > 20 * 1024 * 1024) { notify(`${file.name} is too large (max 20MB)`); continue; }
      try {
        const dataUrl = await fileToDataUrl(file);
        next.push({ id: uid(), file, dataUrl });
      } catch {
        notify(`Unable to process this image: ${file.name}`);
      }
    }
    setItems((prev) => [...prev, ...next]);
  }, []);

  function remove(id: string) {
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  function onDrop(index: number) {
    if (dragIdx === null || dragIdx === index) return;
    setItems((prev) => {
      const next = [...prev];
      const [moved] = next.splice(dragIdx, 1);
      next.splice(index, 0, moved);
      return next;
    });
    setDragIdx(null);
  }

  async function generatePdf() {
    if (items.length === 0) return notify("Add at least one image first.");
    setProcessing(true);
    try {
      let pdf: jsPDF | null = null;
      for (const item of items) {
        const img = await loadImage(item.dataUrl);
        let w: number, h: number;
        if (pageSize === "fit") {
          w = (img.width / 96) * 25.4;
          h = (img.height / 96) * 25.4;
        } else {
          [w, h] = PAGE_SIZES[pageSize];
        }
        const orientation = w > h ? "landscape" : "portrait";
        if (!pdf) {
          pdf = new jsPDF({ orientation, unit: "mm", format: [w, h] });
        } else {
          pdf.addPage([w, h], orientation);
        }
        let drawW = w, drawH = h, offX = 0, offY = 0;
        if (pageSize !== "fit") {
          const imgAspect = img.width / img.height;
          const pageAspect = w / h;
          if (imgAspect > pageAspect) {
            drawW = w;
            drawH = w / imgAspect;
            offY = (h - drawH) / 2;
          } else {
            drawH = h;
            drawW = h * imgAspect;
            offX = (w - drawW) / 2;
          }
        }
        const fmt = item.file.type.includes("png") ? "PNG" : "JPEG";
        pdf.addImage(item.dataUrl, fmt, offX, offY, drawW, drawH);
      }
      pdf?.save("images-to-pdf-sri-venkateshwara.pdf");
      notify("PDF downloaded successfully.");
    } catch {
      notify("We couldn't generate the PDF. Please try again.");
    } finally {
      setProcessing(false);
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 md:px-6 py-8 md:py-10">
      <div className="mb-8">
        <h1 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">Image to PDF</h1>
        <p className="text-fg/60 mt-1">Convert JPG, PNG or WEBP images into a single, organized PDF document. Drag to reorder pages.</p>
      </div>

      <div className="glass-light rounded-2xl border border-white/10 p-5 mb-5">
        <div
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => { e.preventDefault(); if (e.dataTransfer.files.length) handleFiles(e.dataTransfer.files); }}
          className="border-2 border-dashed border-white/15 hover:border-violet/50 rounded-xl p-8 text-center cursor-pointer transition-colors"
        >
          <UploadCloud className="mx-auto mb-2 text-violet" size={28} />
          <p className="text-sm font-medium text-fg">Drag & drop images here, or click to browse</p>
          <p className="text-xs text-fg/40 mt-1">JPG, PNG, WEBP · Max 20MB each · Multiple files supported</p>
          <input ref={inputRef} type="file" multiple accept={ACCEPT.join(",")} className="hidden" onChange={(e) => e.target.files && handleFiles(e.target.files)} />
        </div>
      </div>

      {items.length > 0 && (
        <div className="glass-light rounded-2xl border border-white/10 p-5 mb-5">
          <h3 className="font-semibold text-fg mb-3 text-sm">Page Order ({items.length} page{items.length !== 1 ? "s" : ""}) — drag to reorder</h3>
          <ul className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {items.map((item, idx) => (
              <li
                key={item.id}
                draggable
                onDragStart={() => setDragIdx(idx)}
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => onDrop(idx)}
                className="relative rounded-xl overflow-hidden border border-white/10 bg-black/20 group cursor-move"
              >
                <span className="absolute top-1.5 left-1.5 z-10 w-6 h-6 rounded-full bg-black/70 text-white text-[11px] font-bold flex items-center justify-center">{idx + 1}</span>
                <button onClick={() => remove(item.id)} className="absolute top-1.5 right-1.5 z-10 w-6 h-6 rounded-full bg-black/60 hover:bg-red-500 text-white flex items-center justify-center">
                  <Trash2 size={12} />
                </button>
                <GripVertical size={14} className="absolute bottom-1.5 right-1.5 z-10 text-white/60" />
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={item.dataUrl} alt={item.file.name} className="w-full aspect-[3/4] object-cover" />
                <p className="text-[10px] text-fg/50 px-1.5 py-1 truncate">{formatBytes(item.file.size)}</p>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="glass-light rounded-2xl border border-white/10 p-5 flex flex-col sm:flex-row items-center gap-4 justify-between">
        <label className="text-sm text-fg/70 flex items-center gap-2">
          Page size
          <select value={pageSize} onChange={(e) => setPageSize(e.target.value)} className="bg-transparent border border-white/15 rounded-lg px-3 py-2 text-fg focus-ring">
            <option value="a4" className="bg-surface">A4</option>
            <option value="letter" className="bg-surface">Letter</option>
            <option value="fit" className="bg-surface">Fit to image size</option>
          </select>
        </label>
        <button
          onClick={generatePdf}
          disabled={processing || items.length === 0}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity disabled:opacity-50"
        >
          <Download size={18} /> {processing ? "Generating..." : "Download PDF"}
        </button>
      </div>

      {toast && (
        <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 glass px-5 py-3 rounded-xl shadow-xl text-sm text-fg flex items-center gap-2 animate-fade-up">
          {toast}
          <button onClick={() => setToast(null)}><X size={14} /></button>
        </div>
      )}
    </div>
  );
}
