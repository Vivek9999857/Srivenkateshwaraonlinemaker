"use client";

import { useRef, useState } from "react";
import { PDFDocument } from "pdf-lib";
import { UploadCloud, Download, X, Trash2, RotateCw, Copy } from "lucide-react";
import { downloadBlob } from "@/lib/utils";
import JSZip from "jszip";

interface PageThumb {
  index: number;
  rotation: number;
  deleted: boolean;
}

export default function SplitOrganizePdfPage() {
  const [file, setFile] = useState<File | null>(null);
  const [pages, setPages] = useState<PageThumb[]>([]);
  const [processing, setProcessing] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  function notify(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  }

  async function handleFile(f: File) {
    if (f.type !== "application/pdf") return notify("Unsupported format. Please upload a PDF file.");
    if (f.size > 50 * 1024 * 1024) return notify("File is too large (max 50MB).");
    try {
      const buf = await f.arrayBuffer();
      const doc = await PDFDocument.load(buf);
      const count = doc.getPageCount();
      setFile(f);
      setPages(Array.from({ length: count }, (_, i) => ({ index: i, rotation: 0, deleted: false })));
    } catch {
      notify("Unable to process this PDF. Please try another file.");
    }
  }

  function toggleDelete(idx: number) {
    setPages((prev) => prev.map((p) => (p.index === idx ? { ...p, deleted: !p.deleted } : p)));
  }
  function rotate(idx: number) {
    setPages((prev) => prev.map((p) => (p.index === idx ? { ...p, rotation: (p.rotation + 90) % 360 } : p)));
  }
  function duplicate(idx: number) {
    setPages((prev) => {
      const target = prev.find((p) => p.index === idx)!;
      return [...prev, { ...target, index: prev.length }];
    });
  }

  async function exportPdf() {
    if (!file) return;
    setProcessing(true);
    try {
      const buf = await file.arrayBuffer();
      const src = await PDFDocument.load(buf);
      const out = await PDFDocument.create();
      const kept = pages.filter((p) => !p.deleted);
      for (const p of kept) {
        const [copied] = await out.copyPages(src, [p.index % src.getPageCount()]);
        copied.setRotation({ type: "degrees", angle: p.rotation } as never);
        out.addPage(copied);
      }
      const bytes = await out.save();
      downloadBlob(new Blob([new Uint8Array(bytes)], { type: "application/pdf" }), "organized-sri-venkateshwara.pdf");
      notify("PDF exported successfully.");
    } catch {
      notify("We couldn't export this PDF. Please try again.");
    } finally {
      setProcessing(false);
    }
  }

  async function extractEachPageAsPdf() {
    if (!file) return;
    setProcessing(true);
    try {
      const buf = await file.arrayBuffer();
      const src = await PDFDocument.load(buf);
      const zip = new JSZip();
      const kept = pages.filter((p) => !p.deleted);
      for (let i = 0; i < kept.length; i++) {
        const out = await PDFDocument.create();
        const [copied] = await out.copyPages(src, [kept[i].index % src.getPageCount()]);
        out.addPage(copied);
        const bytes = await out.save();
        zip.file(`page-${i + 1}.pdf`, bytes);
      }
      const blob = await zip.generateAsync({ type: "blob" });
      downloadBlob(blob, "split-pages-sri-venkateshwara.zip");
      notify("Split pages downloaded as ZIP.");
    } catch {
      notify("We couldn't split this PDF. Please try again.");
    } finally {
      setProcessing(false);
    }
  }

  return (
    <div className="max-w-5xl mx-auto px-4 md:px-6 py-8 md:py-10">
      <div className="mb-8">
        <h1 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">Split &amp; Organize PDF Pages</h1>
        <p className="text-fg/60 mt-1">View thumbnails of every page. Rotate, delete, duplicate or extract pages — all processed in your browser.</p>
      </div>

      {!file ? (
        <div
          onClick={() => inputRef.current?.click()}
          className="glass-light border-2 border-dashed border-white/15 hover:border-violet/50 rounded-2xl p-10 text-center cursor-pointer transition-colors"
        >
          <UploadCloud className="mx-auto mb-2 text-violet" size={28} />
          <p className="text-sm font-medium text-fg">Click to upload a PDF file</p>
          <p className="text-xs text-fg/40 mt-1">PDF only · Max 50MB</p>
          <input ref={inputRef} type="file" accept="application/pdf" className="hidden" onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-fg/60">{file.name} · {pages.filter((p) => !p.deleted).length} of {pages.length} pages kept</p>
            <button onClick={() => { setFile(null); setPages([]); }} className="text-xs text-fg/50 hover:text-red-400">Remove file</button>
          </div>
          <div className="glass-light rounded-2xl border border-white/10 p-5 mb-5">
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
              {pages.map((p, i) => (
                <div key={i} className={`relative rounded-xl border p-2 text-center ${p.deleted ? "border-red-500/40 opacity-40" : "border-white/10"}`}>
                  <div
                    className="aspect-[3/4] rounded-lg bg-white flex items-center justify-center text-ink font-bold text-lg mb-2 transition-transform"
                    style={{ transform: `rotate(${p.rotation}deg)` }}
                  >
                    {p.index + 1}
                  </div>
                  <div className="flex items-center justify-center gap-1">
                    <button onClick={() => rotate(p.index)} title="Rotate" className="p-1.5 rounded-lg hover:bg-white/10 text-fg/60"><RotateCw size={13} /></button>
                    <button onClick={() => duplicate(p.index)} title="Duplicate" className="p-1.5 rounded-lg hover:bg-white/10 text-fg/60"><Copy size={13} /></button>
                    <button onClick={() => toggleDelete(p.index)} title="Delete" className="p-1.5 rounded-lg hover:bg-red-500/15 text-fg/60 hover:text-red-400"><Trash2 size={13} /></button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="flex flex-wrap gap-3">
            <button onClick={exportPdf} disabled={processing} className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity disabled:opacity-50">
              <Download size={18} /> Download Organized PDF
            </button>
            <button onClick={extractEachPageAsPdf} disabled={processing} className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold bg-white/5 hover:bg-white/10 text-fg transition-colors disabled:opacity-50">
              <Download size={18} /> Extract Pages as ZIP
            </button>
          </div>
        </>
      )}

      {toast && (
        <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 glass px-5 py-3 rounded-xl shadow-xl text-sm text-fg flex items-center gap-2 animate-fade-up">
          {toast}
          <button onClick={() => setToast(null)}><X size={14} /></button>
        </div>
      )}
    </div>
  );
}
