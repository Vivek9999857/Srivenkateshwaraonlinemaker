"use client";

import { useRef, useState } from "react";
import * as pdfjsLib from "pdfjs-dist";
import JSZip from "jszip";
import { UploadCloud, Download, X } from "lucide-react";
import { downloadBlob } from "@/lib/utils";

pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;

interface PageImg {
  index: number;
  dataUrl: string;
}

export default function PdfToImagePage() {
  const [file, setFile] = useState<File | null>(null);
  const [pages, setPages] = useState<PageImg[]>([]);
  const [format, setFormat] = useState<"jpeg" | "png">("jpeg");
  const [processing, setProcessing] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  function notify(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  }

  async function handleFile(f: File) {
    if (f.type !== "application/pdf") return notify("Unsupported format. Please upload a PDF file.");
    if (f.size > 50 * 1024 * 1024) return notify("File is too large (max 50MB).");
    setFile(f);
    setPages([]);
    setProcessing(true);
    try {
      const buf = await f.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: buf }).promise;
      const results: PageImg[] = [];
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const viewport = page.getViewport({ scale: 2 });
        const canvas = document.createElement("canvas");
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        const ctx = canvas.getContext("2d")!;
        await page.render({ canvasContext: ctx, viewport, canvas }).promise;
        results.push({ index: i, dataUrl: canvas.toDataURL(`image/${format}`, 0.92) });
      }
      setPages(results);
      notify(`Converted ${results.length} page(s) successfully.`);
    } catch {
      notify("Unable to process this PDF. Please try another file.");
    } finally {
      setProcessing(false);
    }
  }

  async function downloadAll() {
    if (pages.length === 0) return;
    if (pages.length === 1) {
      const bin = atob(pages[0].dataUrl.split(",")[1]);
      const arr = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      downloadBlob(new Blob([arr], { type: `image/${format}` }), `page-1.${format === "jpeg" ? "jpg" : "png"}`);
      return;
    }
    const zip = new JSZip();
    for (const p of pages) {
      const bin = atob(p.dataUrl.split(",")[1]);
      const arr = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      zip.file(`page-${p.index}.${format === "jpeg" ? "jpg" : "png"}`, arr);
    }
    const blob = await zip.generateAsync({ type: "blob" });
    downloadBlob(blob, "pdf-pages-sri-venkateshwara.zip");
  }

  return (
    <div className="max-w-5xl mx-auto px-4 md:px-6 py-8 md:py-10">
      <div className="mb-8">
        <h1 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">PDF to Image</h1>
        <p className="text-fg/60 mt-1">Convert every page of your PDF into a high-quality JPG or PNG image — processed locally in your browser.</p>
      </div>

      {!file ? (
        <div onClick={() => inputRef.current?.click()} className="glass-light border-2 border-dashed border-white/15 hover:border-violet/50 rounded-2xl p-10 text-center cursor-pointer transition-colors">
          <UploadCloud className="mx-auto mb-2 text-violet" size={28} />
          <p className="text-sm font-medium text-fg">Click to upload a PDF file</p>
          <p className="text-xs text-fg/40 mt-1">PDF only · Max 50MB</p>
          <input ref={inputRef} type="file" accept="application/pdf" className="hidden" onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
            <p className="text-sm text-fg/60">{file.name} · {pages.length} page(s)</p>
            <div className="flex items-center gap-3">
              <select value={format} onChange={(e) => setFormat(e.target.value as never)} className="bg-transparent border border-white/15 rounded-lg px-3 py-1.5 text-sm text-fg">
                <option value="jpeg" className="bg-surface">JPG</option>
                <option value="png" className="bg-surface">PNG</option>
              </select>
              <button onClick={() => { setFile(null); setPages([]); }} className="text-xs text-fg/50 hover:text-red-400">Remove</button>
            </div>
          </div>
          {processing ? (
            <p className="text-center text-fg/50 py-16">Processing your file...</p>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 mb-6">
              {pages.map((p) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img key={p.index} src={p.dataUrl} alt={`Page ${p.index}`} className="rounded-lg border border-white/10 w-full" />
              ))}
            </div>
          )}
          <button onClick={downloadAll} disabled={pages.length === 0} className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity disabled:opacity-50">
            <Download size={18} /> {pages.length > 1 ? "Download All (ZIP)" : "Download Image"}
          </button>
        </>
      )}

      {toast && (
        <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 glass px-5 py-3 rounded-xl shadow-xl text-sm text-fg flex items-center gap-2 animate-fade-up">
          {toast}
          <button onClick={() => setToast(null)}><X size={14} /></button>
        </div>
      )}
    </div>
  );
}
