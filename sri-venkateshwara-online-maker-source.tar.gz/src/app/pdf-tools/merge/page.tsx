"use client";

import { useRef, useState, useCallback } from "react";
import { PDFDocument } from "pdf-lib";
import { UploadCloud, Trash2, Download, X, FileText } from "lucide-react";
import { uid, formatBytes, downloadBlob } from "@/lib/utils";

interface PdfItem {
  id: string;
  file: File;
  pageCount: number | null;
}

export default function MergePdfPage() {
  const [items, setItems] = useState<PdfItem[]>([]);
  const [processing, setProcessing] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [dragIdx, setDragIdx] = useState<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  function notify(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  }

  const handleFiles = useCallback(async (files: FileList | File[]) => {
    const list = Array.from(files);
    const next: PdfItem[] = [];
    for (const file of list) {
      if (file.type !== "application/pdf") { notify(`Unsupported format: ${file.name}. Please upload PDF files only.`); continue; }
      if (file.size > 50 * 1024 * 1024) { notify(`${file.name} is too large (max 50MB)`); continue; }
      let pageCount: number | null = null;
      try {
        const buf = await file.arrayBuffer();
        const doc = await PDFDocument.load(buf);
        pageCount = doc.getPageCount();
      } catch {
        notify(`Unable to process this PDF: ${file.name}`);
        continue;
      }
      next.push({ id: uid(), file, pageCount });
    }
    setItems((prev) => [...prev, ...next]);
  }, []);

  function remove(id: string) {
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  function onDrop(index: number) {
    if (dragIdx === null || dragIdx === index) return;
    setItems((prev) => {
      const next = [...prev];
      const [moved] = next.splice(dragIdx, 1);
      next.splice(index, 0, moved);
      return next;
    });
    setDragIdx(null);
  }

  async function mergePdfs() {
    if (items.length < 2) return notify("Add at least two PDF files to merge.");
    setProcessing(true);
    try {
      const merged = await PDFDocument.create();
      for (const item of items) {
        const buf = await item.file.arrayBuffer();
        const doc = await PDFDocument.load(buf);
        const pages = await merged.copyPages(doc, doc.getPageIndices());
        pages.forEach((p) => merged.addPage(p));
      }
      const bytes = await merged.save();
      downloadBlob(new Blob([new Uint8Array(bytes)], { type: "application/pdf" }), "merged-sri-venkateshwara.pdf");
      notify("Merged PDF downloaded successfully.");
    } catch {
      notify("We couldn't merge these PDFs. Please try again.");
    } finally {
      setProcessing(false);
    }
  }

  const totalPages = items.reduce((s, i) => s + (i.pageCount ?? 0), 0);

  return (
    <div className="max-w-4xl mx-auto px-4 md:px-6 py-8 md:py-10">
      <div className="mb-8">
        <h1 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">Merge PDF</h1>
        <p className="text-fg/60 mt-1">Combine multiple PDF files into one document. Drag to set the merge order. Processed entirely in your browser.</p>
      </div>

      <div className="glass-light rounded-2xl border border-white/10 p-5 mb-5">
        <div
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => { e.preventDefault(); if (e.dataTransfer.files.length) handleFiles(e.dataTransfer.files); }}
          className="border-2 border-dashed border-white/15 hover:border-violet/50 rounded-xl p-8 text-center cursor-pointer transition-colors"
        >
          <UploadCloud className="mx-auto mb-2 text-violet" size={28} />
          <p className="text-sm font-medium text-fg">Drag & drop PDF files here, or click to browse</p>
          <p className="text-xs text-fg/40 mt-1">PDF only · Max 50MB each</p>
          <input ref={inputRef} type="file" multiple accept="application/pdf" className="hidden" onChange={(e) => e.target.files && handleFiles(e.target.files)} />
        </div>
      </div>

      {items.length > 0 && (
        <div className="glass-light rounded-2xl border border-white/10 p-5 mb-5">
          <h3 className="font-semibold text-fg mb-3 text-sm">Merge Order ({items.length} files · {totalPages} pages total)</h3>
          <ul className="space-y-2">
            {items.map((item, idx) => (
              <li
                key={item.id}
                draggable
                onDragStart={() => setDragIdx(idx)}
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => onDrop(idx)}
                className="flex items-center gap-3 p-3 rounded-xl border border-white/10 bg-black/10 cursor-move"
              >
                <span className="w-7 h-7 rounded-full gradient-primary text-white text-xs font-bold flex items-center justify-center shrink-0">{idx + 1}</span>
                <FileText size={18} className="text-cyan shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-fg truncate">{item.file.name}</p>
                  <p className="text-xs text-fg/45">{item.pageCount ?? "?"} pages · {formatBytes(item.file.size)}</p>
                </div>
                <button onClick={() => remove(item.id)} className="p-1.5 rounded-lg hover:bg-red-500/15 text-fg/40 hover:text-red-400">
                  <Trash2 size={14} />
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="glass-light rounded-2xl border border-white/10 p-5 flex items-center justify-between flex-wrap gap-3">
        <p className="text-sm text-fg/50">Files are merged locally in your browser for privacy — nothing is uploaded to a server.</p>
        <button
          onClick={mergePdfs}
          disabled={processing || items.length < 2}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity disabled:opacity-50"
        >
          <Download size={18} /> {processing ? "Merging..." : "Merge & Download"}
        </button>
      </div>

      {toast && (
        <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 glass px-5 py-3 rounded-xl shadow-xl text-sm text-fg flex items-center gap-2 animate-fade-up">
          {toast}
          <button onClick={() => setToast(null)}><X size={14} /></button>
        </div>
      )}
    </div>
  );
}
