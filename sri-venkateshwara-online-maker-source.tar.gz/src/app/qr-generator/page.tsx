"use client";

import { useEffect, useRef, useState } from "react";
import QRCode from "qrcode";
import { Download, Link as LinkIcon, Wifi, MessageCircle, User, FileText, Image as ImageIcon, X, IndianRupee } from "lucide-react";
import { downloadBlob } from "@/lib/utils";

type QrType = "url" | "text" | "wifi" | "whatsapp" | "contact" | "upi";

const TYPES: { id: QrType; label: string; icon: React.ElementType }[] = [
  { id: "url", label: "Website", icon: LinkIcon },
  { id: "upi", label: "UPI Payment", icon: IndianRupee },
  { id: "whatsapp", label: "WhatsApp", icon: MessageCircle },
  { id: "wifi", label: "Wi-Fi", icon: Wifi },
  { id: "contact", label: "Contact", icon: User },
  { id: "text", label: "Plain Text", icon: FileText },
];

export default function QrGeneratorPage() {
  const [type, setType] = useState<QrType>("url");
  const [fg, setFg] = useState("#0B1020");
  const [bg, setBg] = useState("#FFFFFF");
  const [size, setSize] = useState(400);
  const [margin, setMargin] = useState(2);
  const [ecLevel, setEcLevel] = useState<"L" | "M" | "Q" | "H">("M");
  const [toast, setToast] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [url, setUrl] = useState("https://srivenkateshwaraonlinemaker.com");
  const [text, setText] = useState("Hello from Sri Venkateshwara Online Maker!");
  const [wifiSsid, setWifiSsid] = useState("MyWifiNetwork");
  const [wifiPass, setWifiPass] = useState("");
  const [wifiEnc, setWifiEnc] = useState("WPA");
  const [waNumber, setWaNumber] = useState("91XXXXXXXXXX");
  const [waMsg, setWaMsg] = useState("Hello!");
  const [contactName, setContactName] = useState("Your Name");
  const [contactPhone, setContactPhone] = useState("+91XXXXXXXXXX");
  const [upiId, setUpiId] = useState("yourname@upi");
  const [upiName, setUpiName] = useState("Sri Venkateshwara Online Maker");
  const [upiAmount, setUpiAmount] = useState("");

  function buildValue(): string {
    switch (type) {
      case "url": return url;
      case "text": return text;
      case "wifi": return `WIFI:T:${wifiEnc};S:${wifiSsid};P:${wifiPass};;`;
      case "whatsapp": return `https://wa.me/${waNumber.replace(/\D/g, "")}?text=${encodeURIComponent(waMsg)}`;
      case "contact": return `BEGIN:VCARD\nVERSION:3.0\nFN:${contactName}\nTEL:${contactPhone}\nEND:VCARD`;
      case "upi": return `upi://pay?pa=${upiId}&pn=${encodeURIComponent(upiName)}${upiAmount ? `&am=${upiAmount}` : ""}&cu=INR`;
    }
  }

  useEffect(() => {
    const val = buildValue();
    if (!val || !canvasRef.current) return;
    QRCode.toCanvas(canvasRef.current, val, {
      width: size,
      margin,
      errorCorrectionLevel: ecLevel,
      color: { dark: fg, light: bg },
    }).catch(() => setToast("Unable to generate QR code. Please check your input."));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type, fg, bg, size, margin, ecLevel, url, text, wifiSsid, wifiPass, wifiEnc, waNumber, waMsg, contactName, contactPhone, upiId, upiName, upiAmount]);

  async function downloadPng() {
    if (!canvasRef.current) return;
    canvasRef.current.toBlob((blob) => {
      if (blob) downloadBlob(blob, "qr-code-sri-venkateshwara.png");
    });
  }

  async function downloadSvg() {
    try {
      const svg = await QRCode.toString(buildValue(), { type: "svg", margin, errorCorrectionLevel: ecLevel, color: { dark: fg, light: bg } });
      downloadBlob(new Blob([svg], { type: "image/svg+xml" }), "qr-code-sri-venkateshwara.svg");
    } catch {
      setToast("Unable to export SVG. Please try again.");
    }
  }

  return (
    <div className="max-w-5xl mx-auto px-4 md:px-6 py-8 md:py-10">
      <div className="mb-8">
        <h1 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">QR Code Generator</h1>
        <p className="text-fg/60 mt-1">Generate QR codes for websites, UPI payments, WhatsApp, Wi-Fi, contacts and text — fully customizable.</p>
      </div>

      <div className="grid lg:grid-cols-[1fr_360px] gap-6">
        <div className="space-y-5">
          <div className="glass-light rounded-2xl border border-white/10 p-5">
            <h2 className="font-semibold text-fg mb-3 text-sm">QR Type</h2>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {TYPES.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setType(t.id)}
                  className={`flex flex-col items-center gap-1.5 py-3 rounded-xl text-xs font-medium transition-colors ${type === t.id ? "gradient-primary text-white" : "bg-white/5 hover:bg-white/10 text-fg/70"}`}
                >
                  <t.icon size={16} /> {t.label}
                </button>
              ))}
            </div>
          </div>

          <div className="glass-light rounded-2xl border border-white/10 p-5">
            <h2 className="font-semibold text-fg mb-3 text-sm">Content</h2>
            {type === "url" && <Field label="Website URL" value={url} onChange={setUrl} />}
            {type === "text" && <TextArea label="Text" value={text} onChange={setText} />}
            {type === "wifi" && (
              <div className="space-y-3">
                <Field label="Network Name (SSID)" value={wifiSsid} onChange={setWifiSsid} />
                <Field label="Password" value={wifiPass} onChange={setWifiPass} type="password" />
                <label className="text-xs text-fg/50 block">Encryption
                  <select value={wifiEnc} onChange={(e) => setWifiEnc(e.target.value)} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-3 py-2 text-fg">
                    <option value="WPA" className="bg-surface">WPA/WPA2</option>
                    <option value="WEP" className="bg-surface">WEP</option>
                    <option value="nopass" className="bg-surface">None</option>
                  </select>
                </label>
              </div>
            )}
            {type === "whatsapp" && (
              <div className="space-y-3">
                <Field label="WhatsApp Number (with country code)" value={waNumber} onChange={setWaNumber} />
                <TextArea label="Pre-filled Message" value={waMsg} onChange={setWaMsg} />
              </div>
            )}
            {type === "contact" && (
              <div className="space-y-3">
                <Field label="Name" value={contactName} onChange={setContactName} />
                <Field label="Phone" value={contactPhone} onChange={setContactPhone} />
              </div>
            )}
            {type === "upi" && (
              <div className="space-y-3">
                <Field label="UPI ID" value={upiId} onChange={setUpiId} />
                <Field label="Payee Name" value={upiName} onChange={setUpiName} />
                <Field label="Amount (optional)" value={upiAmount} onChange={setUpiAmount} />
              </div>
            )}
          </div>

          <div className="glass-light rounded-2xl border border-white/10 p-5">
            <h2 className="font-semibold text-fg mb-3 text-sm">Customize</h2>
            <div className="grid grid-cols-2 gap-4">
              <label className="text-xs text-fg/50">Foreground
                <input type="color" value={fg} onChange={(e) => setFg(e.target.value)} className="w-full h-9 mt-1 rounded-lg bg-transparent border border-white/15" />
              </label>
              <label className="text-xs text-fg/50">Background
                <input type="color" value={bg} onChange={(e) => setBg(e.target.value)} className="w-full h-9 mt-1 rounded-lg bg-transparent border border-white/15" />
              </label>
              <label className="text-xs text-fg/50">Size ({size}px)
                <input type="range" min={200} max={800} step={50} value={size} onChange={(e) => setSize(+e.target.value)} className="w-full accent-violet" />
              </label>
              <label className="text-xs text-fg/50">Margin ({margin})
                <input type="range" min={0} max={8} value={margin} onChange={(e) => setMargin(+e.target.value)} className="w-full accent-violet" />
              </label>
              <label className="text-xs text-fg/50 col-span-2">Error Correction
                <select value={ecLevel} onChange={(e) => setEcLevel(e.target.value as never)} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-3 py-2 text-fg">
                  <option value="L" className="bg-surface">Low (L)</option>
                  <option value="M" className="bg-surface">Medium (M)</option>
                  <option value="Q" className="bg-surface">Quartile (Q)</option>
                  <option value="H" className="bg-surface">High (H)</option>
                </select>
              </label>
            </div>
          </div>
        </div>

        <div className="glass-light rounded-2xl border border-white/10 p-6 flex flex-col items-center gap-5 h-fit sticky top-20">
          <div className="rounded-2xl overflow-hidden shadow-xl bg-white p-3">
            <canvas ref={canvasRef} className="max-w-full" />
          </div>
          <div className="grid grid-cols-2 gap-3 w-full">
            <button onClick={downloadPng} className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity text-sm">
              <ImageIcon size={16} /> PNG
            </button>
            <button onClick={downloadSvg} className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold bg-white/5 hover:bg-white/10 text-fg transition-colors text-sm">
              <Download size={16} /> SVG
            </button>
          </div>
        </div>
      </div>

      {toast && (
        <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 glass px-5 py-3 rounded-xl shadow-xl text-sm text-fg flex items-center gap-2 animate-fade-up">
          {toast}
          <button onClick={() => setToast(null)}><X size={14} /></button>
        </div>
      )}
    </div>
  );
}

function Field({ label, value, onChange, type = "text" }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <label className="text-xs text-fg/50 block">
      {label}
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-3 py-2 text-fg text-sm" />
    </label>
  );
}
function TextArea({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="text-xs text-fg/50 block">
      {label}
      <textarea value={value} onChange={(e) => onChange(e.target.value)} rows={3} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-3 py-2 text-fg text-sm" />
    </label>
  );
}
