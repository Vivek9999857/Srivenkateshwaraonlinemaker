import Link from "next/link";
import {
  Search, Zap, ShieldCheck, PrinterCheck, MapPin, UploadCloud, SlidersHorizontal,
  Eye, Download, ChevronRight, HelpCircle
} from "lucide-react";
import HeroVisual from "@/components/HeroVisual";
import FeatureCard from "@/components/QuickStat";
import ToolCard from "@/components/ToolCard";
import { TOOLS, CATEGORY_LABELS } from "@/lib/tools-data";

const QUICK_ACTIONS = [
  { label: "Passport Photo", href: "/passport-photo-pdf" },
  { label: "Image to PDF", href: "/pdf-tools/image-to-pdf" },
  { label: "PDF Tools", href: "/all-tools?cat=pdf" },
  { label: "Photo Resize", href: "/photo-resize" },
  { label: "ID Card Maker", href: "/id-card-maker" },
  { label: "Resume Maker", href: "/resume-maker" },
  { label: "Poster Maker", href: "/design-studio?template=poster" },
];

const WORKFLOW = [
  { icon: UploadCloud, title: "Upload", desc: "Add your photo, document or PDF — drag & drop or pick from your device." },
  { icon: SlidersHorizontal, title: "Edit", desc: "Crop, resize, adjust colors, arrange pages or design your layout." },
  { icon: Eye, title: "Preview", desc: "See an exact, print-accurate preview before you commit." },
  { icon: Download, title: "Download / Print", desc: "Export as PDF, JPG or PNG, or send straight to your printer." },
];

const WHY_US = [
  { icon: Zap, title: "Fast", desc: "Most tools run right in your browser for instant results." },
  { icon: ShieldCheck, title: "Secure", desc: "Files are processed for your task only and auto-removed after." },
  { icon: PrinterCheck, title: "Print-Accurate", desc: "Exact mm/DPI precision — what you see is what gets printed." },
  { icon: MapPin, title: "Made for India", desc: "Passport sizes, formats and templates built for Indian needs." },
];

const FAQS = [
  { q: "Is Sri Venkateshwara Online Maker free to use?", a: "Yes. Most tools including passport photo maker, image to PDF and PDF merge are free. Advanced batch and business features are part of our Pro and Cyber Cafe plans." },
  { q: "Do I need to create an account?", a: "No account is needed for most browser-based tools. You can sign in to save your projects, templates and download history." },
  { q: "Are my uploaded photos and documents safe?", a: "Yes. Files are processed only for the task you request, and temporary files are automatically deleted according to our retention policy. We never publish your files publicly." },
  { q: "Can I print directly from the website?", a: "Yes. Our print-ready tools generate exact-dimension PDFs you can print at home, at a shop, or send to our Cyber Cafe workflow." },
];

export default function Home() {
  const popularTools = TOOLS.filter((t) => t.popular);

  return (
    <div className="overflow-x-hidden">
      {/* HERO */}
      <section className="relative pt-12 md:pt-20 pb-16 px-4 md:px-6">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top_right,rgba(124,58,237,0.18),transparent_55%),radial-gradient(ellipse_at_bottom_left,rgba(6,182,212,0.14),transparent_55%)]" />
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-10 items-center">
          <div className="text-center lg:text-left order-2 lg:order-1">
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass text-xs font-medium text-fg/80 mb-5 animate-fade-up">
              🙏 Welcome
            </span>
            <h1 className="font-[family-name:var(--font-manrope)] font-extrabold text-3xl sm:text-4xl md:text-5xl leading-[1.1] tracking-tight text-fg animate-fade-up">
              SRI VENKATESHWARA
              <br />
              <span className="gradient-text">ONLINE MAKER</span>
            </h1>
            <p className="mt-4 text-lg font-semibold text-cyan animate-fade-up">Create. Convert. Design. Print.</p>
            <p className="mt-3 text-fg/60 max-w-xl mx-auto lg:mx-0 leading-relaxed animate-fade-up">
              Powerful online tools for photos, PDFs, documents, designs and professional printing — all in one place.
            </p>
            <div className="mt-7 flex flex-col sm:flex-row gap-3 justify-center lg:justify-start animate-fade-up">
              <Link
                href="/all-tools"
                className="relative overflow-hidden inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-semibold text-white gradient-primary shadow-xl shadow-violet-deep/30 hover:shadow-violet-deep/50 hover:-translate-y-0.5 transition-all"
              >
                <span className="absolute inset-0 animate-shimmer" />
                <span className="relative">Start Creating</span>
              </Link>
              <Link
                href="/all-tools"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-semibold border border-white/15 text-fg hover:bg-white/5 hover:-translate-y-0.5 transition-all"
              >
                Explore All Tools <ChevronRight size={16} />
              </Link>
            </div>
          </div>
          <div className="order-1 lg:order-2">
            <HeroVisual />
          </div>
        </div>

        {/* SMART SEARCH */}
        <div className="max-w-3xl mx-auto mt-14">
          <Link
            href="/all-tools"
            className="flex items-center gap-3 glass rounded-2xl px-5 py-4 shadow-xl shadow-black/20 hover:border-cyan/40 border border-white/10 transition-colors"
          >
            <Search size={20} className="text-fg/40" />
            <span className="text-fg/45 text-sm">Search tools, services, photo makers, PDF tools...</span>
          </Link>
          <div className="flex flex-wrap gap-2 justify-center mt-4">
            {QUICK_ACTIONS.map((a) => (
              <Link
                key={a.label}
                href={a.href}
                className="px-4 py-2 rounded-full text-sm font-medium glass-light border border-white/10 text-fg/75 hover:text-fg hover:border-violet/40 transition-colors"
              >
                {a.label}
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* POPULAR TOOLS */}
      <section className="max-w-7xl mx-auto px-4 md:px-6 py-14">
        <div className="flex items-end justify-between mb-6">
          <div>
            <h2 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">Popular Tools</h2>
            <p className="text-fg/55 mt-1">Jump straight into the most-used tools on the platform.</p>
          </div>
          <Link href="/all-tools" className="hidden sm:flex items-center gap-1 text-sm font-medium text-cyan hover:gap-2 transition-all">
            View all <ChevronRight size={15} />
          </Link>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {popularTools.map((t) => (
            <ToolCard key={t.id} tool={t} />
          ))}
        </div>
      </section>

      {/* WORKFLOW STRIP */}
      <section className="max-w-7xl mx-auto px-4 md:px-6 py-14">
        <div className="text-center mb-10">
          <h2 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">How Your File Flows</h2>
          <p className="text-fg/55 mt-1">One consistent, print-accurate workflow across every tool.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 relative">
          {WORKFLOW.map((step, i) => (
            <div key={step.title} className="relative rounded-2xl glass-light border border-white/10 p-6 text-center">
              <span className="absolute -top-3 -left-3 w-7 h-7 rounded-full gradient-primary text-white text-xs font-bold flex items-center justify-center">
                {i + 1}
              </span>
              <span className="w-14 h-14 mx-auto rounded-2xl gradient-primary flex items-center justify-center mb-3">
                <step.icon size={24} className="text-white" />
              </span>
              <h3 className="font-semibold text-fg">{step.title}</h3>
              <p className="text-sm text-fg/55 mt-1">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CATEGORY SECTIONS */}
      {(["photo", "pdf", "document", "design"] as const).map((cat) => (
        <section key={cat} className="max-w-7xl mx-auto px-4 md:px-6 py-10">
          <div className="flex items-end justify-between mb-5">
            <h2 className="font-[family-name:var(--font-manrope)] text-xl md:text-2xl font-bold text-fg">{CATEGORY_LABELS[cat]}</h2>
            <Link href={`/all-tools?cat=${cat}`} className="text-sm font-medium text-cyan hover:underline">
              See all
            </Link>
          </div>
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2 snap-x">
            {TOOLS.filter((t) => t.category === cat).slice(0, 6).map((t) => (
              <div key={t.id} className="min-w-[260px] snap-start">
                <ToolCard tool={t} />
              </div>
            ))}
          </div>
        </section>
      ))}

      {/* CYBER CAFE TEASER */}
      <section className="max-w-7xl mx-auto px-4 md:px-6 py-14">
        <div className="rounded-3xl glass p-6 md:p-10 grid lg:grid-cols-2 gap-8 items-center border border-white/10">
          <div>
            <span className="inline-block px-3 py-1 rounded-full bg-cyan/10 text-cyan text-xs font-semibold mb-4">CYBER CAFE MODE</span>
            <h2 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">Run your shop at full speed</h2>
            <p className="text-fg/60 mt-3 leading-relaxed">
              Manage every customer&apos;s photo, ID card and print job in one queue — track pending, ready and completed jobs, reprint instantly, and never lose a customer&apos;s work.
            </p>
            <Link href="/cyber-cafe" className="inline-flex items-center gap-2 mt-5 px-5 py-3 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity">
              Open Cyber Cafe Workspace <ChevronRight size={16} />
            </Link>
          </div>
          <div className="space-y-3">
            {[
              { id: "#001", job: "Passport Photo · 8 copies · A4", status: "Ready", color: "bg-emerald-500/15 text-emerald-400" },
              { id: "#002", job: "ID Card · 2 cards", status: "Pending", color: "bg-amber-500/15 text-amber-400" },
              { id: "#003", job: "PDF · 14 pages", status: "Completed", color: "bg-cyan/15 text-cyan" },
            ].map((c) => (
              <div key={c.id} className="flex items-center justify-between glass-light rounded-xl px-4 py-3 border border-white/10">
                <div>
                  <p className="font-semibold text-fg text-sm">Customer {c.id}</p>
                  <p className="text-xs text-fg/50">{c.job}</p>
                </div>
                <span className={`text-xs font-semibold px-3 py-1 rounded-full ${c.color}`}>{c.status}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="max-w-7xl mx-auto px-4 md:px-6 py-14">
        <div className="text-center mb-10">
          <h2 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">Why Choose Us</h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {WHY_US.map((f) => (
            <FeatureCard key={f.title} icon={f.icon} title={f.title} description={f.desc} />
          ))}
        </div>
      </section>

      {/* SECURITY */}
      <section className="max-w-5xl mx-auto px-4 md:px-6 py-14">
        <div className="rounded-3xl glass-light border border-white/10 p-8 md:p-10 text-center">
          <ShieldCheck size={36} className="mx-auto text-cyan mb-4" />
          <h2 className="font-[family-name:var(--font-manrope)] text-xl md:text-2xl font-bold text-fg">Your Privacy Matters</h2>
          <p className="text-fg/60 mt-3 max-w-2xl mx-auto leading-relaxed">
            Files are processed only for the requested task and temporary files are automatically removed according to the configured retention policy. We never expose your uploads publicly.
          </p>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="max-w-3xl mx-auto px-4 md:px-6 py-14">
        <div className="text-center mb-8">
          <h2 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">Frequently Asked Questions</h2>
        </div>
        <div className="space-y-3">
          {FAQS.map((f) => (
            <details key={f.q} className="group glass-light rounded-xl border border-white/10 p-5">
              <summary className="flex items-center justify-between cursor-pointer font-medium text-fg list-none">
                <span className="flex items-center gap-2"><HelpCircle size={16} className="text-cyan shrink-0" />{f.q}</span>
                <ChevronRight size={16} className="text-fg/40 group-open:rotate-90 transition-transform shrink-0" />
              </summary>
              <p className="text-sm text-fg/60 mt-3 leading-relaxed pl-6">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="max-w-5xl mx-auto px-4 md:px-6 pb-20">
        <div className="rounded-3xl gradient-primary p-10 md:p-14 text-center relative overflow-hidden">
          <div className="absolute inset-0 animate-shimmer opacity-30" />
          <h2 className="relative font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-white">
            Everything You Need for Your Digital Work
          </h2>
          <p className="relative text-white/80 mt-2">One platform. Every digital job.</p>
          <Link
            href="/all-tools"
            className="relative inline-flex items-center gap-2 mt-6 px-7 py-3.5 rounded-xl font-semibold bg-white text-violet-deep hover:bg-white/90 transition-colors"
          >
            Explore All Tools <ChevronRight size={16} />
          </Link>
        </div>
      </section>
    </div>
  );
}
