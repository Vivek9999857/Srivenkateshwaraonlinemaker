"use client";

import { Suspense, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import html2canvas from "html2canvas";
import {
  Type, Square, Circle as CircleIcon, Image as ImageIcon, Trash2, Download,
  Bold, Italic, ChevronUp, ChevronDown, Copy, Lock, Unlock, Undo2, Redo2, X
} from "lucide-react";
import { fileToDataUrl } from "@/lib/image-ops";
import { uid, downloadBlob } from "@/lib/utils";

type ElType = "text" | "rect" | "circle" | "image";

interface Element {
  id: string;
  type: ElType;
  x: number; y: number; w: number; h: number;
  text?: string;
  fontSize?: number;
  bold?: boolean;
  italic?: boolean;
  color?: string;
  fill?: string;
  rotation: number;
  opacity: number;
  locked: boolean;
  src?: string;
}

const TEMPLATE_BG: Record<string, string> = {
  poster: "linear-gradient(135deg, #7C3AED, #06B6D4)",
  "visiting-card": "#F8FAFC",
  certificate: "#FFFBEB",
  social: "linear-gradient(135deg, #111827, #6D28D9)",
};

const CANVAS_SIZE: Record<string, { w: number; h: number }> = {
  poster: { w: 400, h: 560 },
  "visiting-card": { w: 500, h: 290 },
  certificate: { w: 560, h: 400 },
  social: { w: 400, h: 400 },
};

function DesignStudioInner() {
  const params = useSearchParams();
  const template = params.get("template") || "poster";
  const [elements, setElements] = useState<Element[]>([
    { id: uid(), type: "text", x: 40, y: 40, w: 300, h: 60, text: "Your Headline Here", fontSize: 28, bold: true, color: "#FFFFFF", rotation: 0, opacity: 1, locked: false },
  ]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [history, setHistory] = useState<Element[][]>([]);
  const [future, setFuture] = useState<Element[][]>([]);
  const [toast, setToast] = useState<string | null>(null);
  const canvasRef = useRef<HTMLDivElement>(null);
  const imgInputRef = useRef<HTMLInputElement>(null);

  const size = CANVAS_SIZE[template] ?? CANVAS_SIZE.poster;
  const selected = elements.find((e) => e.id === selectedId);

  function notify(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  }

  function pushHistory() {
    setHistory((h) => [...h, elements]);
    setFuture([]);
  }

  function addText() {
    pushHistory();
    const el: Element = { id: uid(), type: "text", x: 30, y: 30, w: 200, h: 40, text: "New Text", fontSize: 18, color: "#111827", rotation: 0, opacity: 1, locked: false };
    setElements((prev) => [...prev, el]);
    setSelectedId(el.id);
  }
  function addShape(type: "rect" | "circle") {
    pushHistory();
    const el: Element = { id: uid(), type, x: 50, y: 50, w: 100, h: 100, fill: "#7C3AED", rotation: 0, opacity: 1, locked: false };
    setElements((prev) => [...prev, el]);
    setSelectedId(el.id);
  }
  async function addImage(f: File) {
    try {
      const src = await fileToDataUrl(f);
      pushHistory();
      const el: Element = { id: uid(), type: "image", x: 40, y: 40, w: 150, h: 150, src, rotation: 0, opacity: 1, locked: false };
      setElements((prev) => [...prev, el]);
      setSelectedId(el.id);
    } catch {
      notify("Unable to load this image.");
    }
  }

  function update(id: string, patch: Partial<Element>) {
    setElements((prev) => prev.map((e) => (e.id === id ? { ...e, ...patch } : e)));
  }
  function removeEl(id: string) {
    pushHistory();
    setElements((prev) => prev.filter((e) => e.id !== id));
    setSelectedId(null);
  }
  function duplicateEl(id: string) {
    pushHistory();
    const el = elements.find((e) => e.id === id);
    if (!el) return;
    const copy = { ...el, id: uid(), x: el.x + 15, y: el.y + 15 };
    setElements((prev) => [...prev, copy]);
    setSelectedId(copy.id);
  }
  function undo() {
    if (history.length === 0) return;
    const prev = history[history.length - 1];
    setFuture((f) => [elements, ...f]);
    setElements(prev);
    setHistory((h) => h.slice(0, -1));
  }
  function redo() {
    if (future.length === 0) return;
    const next = future[0];
    setHistory((h) => [...h, elements]);
    setElements(next);
    setFuture((f) => f.slice(1));
  }

  function onDrag(e: React.MouseEvent, id: string) {
    const el = elements.find((x) => x.id === id);
    if (!el || el.locked) return;
    const startX = e.clientX, startY = e.clientY;
    const origX = el.x, origY = el.y;
    function onMove(ev: MouseEvent) {
      const dx = ev.clientX - startX, dy = ev.clientY - startY;
      update(id, { x: origX + dx, y: origY + dy });
    }
    function onUp() {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    }
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  }

  async function exportPng() {
    if (!canvasRef.current) return;
    try {
      const canvas = await html2canvas(canvasRef.current, { scale: 2 });
      canvas.toBlob((b) => b && downloadBlob(b, `design-${template}-sri-venkateshwara.png`));
      notify("Design exported successfully.");
    } catch {
      notify("Unable to export design. Please try again.");
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-10">
      <div className="mb-6 flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg capitalize">{template.replace("-", " ")} — Design Studio</h1>
          <p className="text-fg/60 mt-1 text-sm">Add text, shapes, and images. Drag to move, use the panel to style. Fully editable canvas.</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={undo} disabled={!history.length} className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-fg/60 disabled:opacity-30"><Undo2 size={16} /></button>
          <button onClick={redo} disabled={!future.length} className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-fg/60 disabled:opacity-30"><Redo2 size={16} /></button>
          <button onClick={exportPng} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity text-sm"><Download size={16} /> Export PNG</button>
        </div>
      </div>

      <div className="grid lg:grid-cols-[220px_1fr_280px] gap-5">
        {/* Toolbox */}
        <div className="glass-light rounded-2xl border border-white/10 p-4 space-y-2 h-fit">
          <button onClick={addText} className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-sm text-fg"><Type size={15} /> Add Text</button>
          <button onClick={() => addShape("rect")} className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-sm text-fg"><Square size={15} /> Rectangle</button>
          <button onClick={() => addShape("circle")} className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-sm text-fg"><CircleIcon size={15} /> Circle</button>
          <button onClick={() => imgInputRef.current?.click()} className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-sm text-fg"><ImageIcon size={15} /> Add Image</button>
          <input ref={imgInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && addImage(e.target.files[0])} />
        </div>

        {/* Canvas */}
        <div className="glass-light rounded-2xl border border-white/10 p-6 flex items-center justify-center overflow-auto">
          <div
            ref={canvasRef}
            className="relative shadow-2xl"
            style={{ width: size.w, height: size.h, background: TEMPLATE_BG[template] ?? "#fff" }}
            onClick={() => setSelectedId(null)}
          >
            {elements.map((el) => (
              <div
                key={el.id}
                onMouseDown={(e) => { e.stopPropagation(); setSelectedId(el.id); onDrag(e, el.id); }}
                className={`absolute select-none ${selectedId === el.id ? "outline outline-2 outline-cyan" : ""} ${el.locked ? "cursor-not-allowed" : "cursor-move"}`}
                style={{ left: el.x, top: el.y, width: el.w, height: el.h, transform: `rotate(${el.rotation}deg)`, opacity: el.opacity }}
              >
                {el.type === "text" && (
                  <p style={{ fontSize: el.fontSize, fontWeight: el.bold ? 700 : 400, fontStyle: el.italic ? "italic" : "normal", color: el.color }} className="w-full h-full whitespace-pre-wrap break-words">
                    {el.text}
                  </p>
                )}
                {el.type === "rect" && <div className="w-full h-full rounded-md" style={{ background: el.fill }} />}
                {el.type === "circle" && <div className="w-full h-full rounded-full" style={{ background: el.fill }} />}
                {el.type === "image" && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={el.src} alt="" className="w-full h-full object-cover rounded-md" />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Properties panel */}
        <div className="glass-light rounded-2xl border border-white/10 p-4 space-y-3 h-fit">
          <h3 className="text-sm font-semibold text-fg">Properties</h3>
          {!selected ? (
            <p className="text-xs text-fg/40">Select an element on the canvas to edit its properties.</p>
          ) : (
            <>
              {selected.type === "text" && (
                <>
                  <textarea value={selected.text} onChange={(e) => update(selected.id, { text: e.target.value })} className="w-full bg-transparent border border-white/15 rounded-lg px-3 py-2 text-fg text-sm" rows={2} />
                  <div className="flex items-center gap-2">
                    <button onClick={() => update(selected.id, { bold: !selected.bold })} className={`p-2 rounded-lg ${selected.bold ? "gradient-primary text-white" : "bg-white/5 text-fg/60"}`}><Bold size={14} /></button>
                    <button onClick={() => update(selected.id, { italic: !selected.italic })} className={`p-2 rounded-lg ${selected.italic ? "gradient-primary text-white" : "bg-white/5 text-fg/60"}`}><Italic size={14} /></button>
                    <input type="color" value={selected.color} onChange={(e) => update(selected.id, { color: e.target.value })} className="w-9 h-9 rounded-lg border border-white/15 bg-transparent" />
                  </div>
                  <label className="text-xs text-fg/50 block">Font size ({selected.fontSize}px)
                    <input type="range" min={10} max={64} value={selected.fontSize} onChange={(e) => update(selected.id, { fontSize: +e.target.value })} className="w-full accent-violet" />
                  </label>
                </>
              )}
              {(selected.type === "rect" || selected.type === "circle") && (
                <label className="text-xs text-fg/50 block">Fill color
                  <input type="color" value={selected.fill} onChange={(e) => update(selected.id, { fill: e.target.value })} className="w-full h-9 mt-1 rounded-lg border border-white/15 bg-transparent" />
                </label>
              )}
              <label className="text-xs text-fg/50 block">Rotation ({selected.rotation}°)
                <input type="range" min={0} max={360} value={selected.rotation} onChange={(e) => update(selected.id, { rotation: +e.target.value })} className="w-full accent-violet" />
              </label>
              <label className="text-xs text-fg/50 block">Opacity ({Math.round(selected.opacity * 100)}%)
                <input type="range" min={0.1} max={1} step={0.05} value={selected.opacity} onChange={(e) => update(selected.id, { opacity: +e.target.value })} className="w-full accent-violet" />
              </label>
              <div className="flex items-center gap-2 pt-2 border-t border-white/10">
                <button onClick={() => update(selected.id, { locked: !selected.locked })} className="flex-1 p-2 rounded-lg bg-white/5 hover:bg-white/10 text-fg/60 flex items-center justify-center gap-1 text-xs">
                  {selected.locked ? <Lock size={13} /> : <Unlock size={13} />} {selected.locked ? "Locked" : "Lock"}
                </button>
                <button onClick={() => duplicateEl(selected.id)} className="flex-1 p-2 rounded-lg bg-white/5 hover:bg-white/10 text-fg/60 flex items-center justify-center gap-1 text-xs"><Copy size={13} /> Copy</button>
                <button onClick={() => removeEl(selected.id)} className="flex-1 p-2 rounded-lg bg-white/5 hover:bg-red-500/15 text-fg/60 hover:text-red-400 flex items-center justify-center gap-1 text-xs"><Trash2 size={13} /> Delete</button>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => setElements((prev) => { const i = prev.findIndex(e=>e.id===selected.id); if(i<=0) return prev; const n=[...prev]; [n[i-1],n[i]]=[n[i],n[i-1]]; return n; })} className="flex-1 p-2 rounded-lg bg-white/5 hover:bg-white/10 text-fg/60 flex items-center justify-center gap-1 text-xs"><ChevronDown size={13} /> Back</button>
                <button onClick={() => setElements((prev) => { const i = prev.findIndex(e=>e.id===selected.id); if(i>=prev.length-1) return prev; const n=[...prev]; [n[i+1],n[i]]=[n[i],n[i+1]]; return n; })} className="flex-1 p-2 rounded-lg bg-white/5 hover:bg-white/10 text-fg/60 flex items-center justify-center gap-1 text-xs"><ChevronUp size={13} /> Front</button>
              </div>
            </>
          )}
        </div>
      </div>

      {toast && (
        <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 glass px-5 py-3 rounded-xl shadow-xl text-sm text-fg flex items-center gap-2 animate-fade-up">
          {toast}
          <button onClick={() => setToast(null)}><X size={14} /></button>
        </div>
      )}
    </div>
  );
}

export default function DesignStudioPage() {
  return (
    <Suspense fallback={<div className="max-w-7xl mx-auto px-4 py-20 text-center text-fg/50">Loading design studio...</div>}>
      <DesignStudioInner />
    </Suspense>
  );
}
