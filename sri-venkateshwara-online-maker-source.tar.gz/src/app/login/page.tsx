"use client";

import { useState } from "react";
import Link from "next/link";
import { Mail, Lock, Globe, ArrowRight } from "lucide-react";
import { Logo } from "@/components/Logo";

export default function LoginPage() {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState<string | null>(null);

  function submit() {
    if (!email || !password) {
      setMessage("Please fill in both email and password.");
      return;
    }
    setMessage("This is a demo account system. In production, this connects to a secure authentication backend.");
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-14">
      <div className="w-full max-w-md glass-light rounded-3xl border border-white/10 p-8">
        <div className="flex justify-center mb-6"><Logo size={44} /></div>
        <h1 className="text-center font-[family-name:var(--font-manrope)] text-xl font-bold text-fg mb-1">
          {mode === "login" ? "Welcome back" : "Create your account"}
        </h1>
        <p className="text-center text-sm text-fg/50 mb-6">
          {mode === "login" ? "Sign in to access your saved projects and templates." : "Guest mode is always available — sign up only for saved history."}
        </p>

        <button className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border border-white/15 hover:bg-white/5 text-fg font-medium text-sm mb-4 transition-colors">
          <Globe size={18} /> Continue with Google
        </button>
        <div className="flex items-center gap-3 mb-4">
          <div className="flex-1 h-px bg-white/10" />
          <span className="text-xs text-fg/40">or</span>
          <div className="flex-1 h-px bg-white/10" />
        </div>

        <div className="space-y-3">
          <label className="block">
            <span className="text-xs text-fg/50">Email</span>
            <div className="flex items-center gap-2 mt-1 border border-white/15 rounded-xl px-3 py-2.5">
              <Mail size={16} className="text-fg/40" />
              <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" className="flex-1 bg-transparent outline-none text-fg text-sm" placeholder="you@email.com" />
            </div>
          </label>
          <label className="block">
            <span className="text-xs text-fg/50">Password</span>
            <div className="flex items-center gap-2 mt-1 border border-white/15 rounded-xl px-3 py-2.5">
              <Lock size={16} className="text-fg/40" />
              <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" className="flex-1 bg-transparent outline-none text-fg text-sm" placeholder="••••••••" />
            </div>
          </label>
        </div>

        {message && <p className="text-xs text-cyan mt-4 bg-cyan/10 rounded-lg p-3">{message}</p>}

        <button onClick={submit} className="w-full mt-5 inline-flex items-center justify-center gap-2 py-3 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity">
          {mode === "login" ? "Sign In" : "Create Account"} <ArrowRight size={16} />
        </button>

        <p className="text-center text-sm text-fg/50 mt-5">
          {mode === "login" ? "Don't have an account?" : "Already have an account?"}{" "}
          <button onClick={() => setMode(mode === "login" ? "signup" : "login")} className="text-cyan font-medium hover:underline">
            {mode === "login" ? "Sign up" : "Sign in"}
          </button>
        </p>
        <p className="text-center text-xs text-fg/35 mt-4">
          Prefer not to sign in? <Link href="/all-tools" className="text-fg/60 hover:text-fg underline">Continue as guest</Link>
        </p>
      </div>
    </div>
  );
}
