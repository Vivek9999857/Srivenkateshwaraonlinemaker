export const metadata = { title: "Refund Policy" };

export default function RefundPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 md:px-6 py-14">
      <h1 className="font-[family-name:var(--font-manrope)] text-3xl font-bold text-fg mb-6">Refund Policy</h1>
      <div className="space-y-5 text-fg/70 leading-relaxed text-sm">
        <p>We want you to be satisfied with Sri Venkateshwara Online Maker.</p>
        <h2 className="text-lg font-semibold text-fg mt-6">Free Tools</h2>
        <p>Free tools have no charge and therefore no refund applies.</p>
        <h2 className="text-lg font-semibold text-fg mt-6">Subscription Plans</h2>
        <p>Pro and Business subscriptions may be cancelled at any time from your account settings. Unused portions of a billing period are handled according to the refund terms configured by the platform administrator at the time of purchase, which will be clearly stated on the pricing page.</p>
        <h2 className="text-lg font-semibold text-fg mt-6">Contact</h2>
        <p>For billing questions, please reach out through our Help Center.</p>
      </div>
    </div>
  );
}
