import type { MetadataRoute } from "next";
import { TOOLS } from "@/lib/tools-data";

const BASE = "https://srivenkateshwaraonlinemaker.com";

const STATIC_ROUTES = [
  "", "/all-tools", "/pricing", "/help", "/login", "/cyber-cafe", "/about",
  "/privacy", "/terms", "/refund",
];

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  const staticEntries: MetadataRoute.Sitemap = STATIC_ROUTES.map((route) => ({
    url: `${BASE}${route}`,
    lastModified: now,
    changeFrequency: "weekly",
    priority: route === "" ? 1 : 0.7,
  }));

  const toolRoutes = Array.from(new Set(TOOLS.filter((t) => t.status === "live").map((t) => t.href.split("?")[0])));
  const toolEntries: MetadataRoute.Sitemap = toolRoutes.map((href) => ({
    url: `${BASE}${href}`,
    lastModified: now,
    changeFrequency: "monthly",
    priority: 0.8,
  }));

  return [...staticEntries, ...toolEntries];
}
