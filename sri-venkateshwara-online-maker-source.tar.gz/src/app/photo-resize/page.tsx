"use client";

import { Suspense, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { UploadCloud, Download, X } from "lucide-react";
import { fileToDataUrl, loadImage } from "@/lib/image-ops";
import { downloadBlob, formatBytes } from "@/lib/utils";

type Unit = "px" | "mm" | "inch" | "cm";

function PhotoResizeInner() {
  const params = useSearchParams();
  const mode = params.get("mode") || "resize";
  const [dataUrl, setDataUrl] = useState<string | null>(null);
  const [origSize, setOrigSize] = useState({ w: 0, h: 0, bytes: 0 });
  const [width, setWidth] = useState(800);
  const [height, setHeight] = useState(600);
  const [unit, setUnit] = useState<Unit>("px");
  const [dpi, setDpi] = useState(300);
  const [lockAspect, setLockAspect] = useState(true);
  const [quality, setQuality] = useState(80);
  const [format, setFormat] = useState<"jpeg" | "png" | "webp">("jpeg");
  const [toast, setToast] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [resultBytes, setResultBytes] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  function notify(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  }

  function toPx(v: number, u: Unit) {
    if (u === "px") return v;
    if (u === "mm") return Math.round((v / 25.4) * dpi);
    if (u === "cm") return Math.round((v / 2.54) * dpi);
    return Math.round(v * dpi);
  }

  async function handleFile(f: File) {
    if (!["image/jpeg", "image/png", "image/webp"].includes(f.type)) return notify("Unsupported format. Please upload JPG, PNG or WEBP.");
    if (f.size > 20 * 1024 * 1024) return notify("File is too large (max 20MB).");
    try {
      const du = await fileToDataUrl(f);
      const img = await loadImage(du);
      setDataUrl(du);
      setOrigSize({ w: img.width, h: img.height, bytes: f.size });
      setWidth(img.width);
      setHeight(img.height);
      setResultUrl(null);
    } catch {
      notify("Unable to process this image. Please try another file.");
    }
  }

  function onWidthChange(v: number) {
    setWidth(v);
    if (lockAspect && origSize.w) setHeight(Math.round((v * origSize.h) / origSize.w));
  }
  function onHeightChange(v: number) {
    setHeight(v);
    if (lockAspect && origSize.h) setWidth(Math.round((v * origSize.w) / origSize.h));
  }

  async function process() {
    if (!dataUrl) return notify("Upload a photo first.");
    try {
      const img = await loadImage(dataUrl);
      const targetW = mode === "compress" ? img.width : toPx(width, unit);
      const targetH = mode === "compress" ? img.height : toPx(height, unit);
      const canvas = document.createElement("canvas");
      canvas.width = targetW;
      canvas.height = targetH;
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(img, 0, 0, targetW, targetH);
      const mime = `image/${format}`;
      const q = format === "png" ? undefined : quality / 100;
      const out = canvas.toDataURL(mime, q);
      setResultUrl(out);
      const bin = atob(out.split(",")[1]);
      setResultBytes(bin.length);
      notify("Image processed successfully.");
    } catch {
      notify("Unable to process this image. Please try again.");
    }
  }

  function download() {
    if (!resultUrl) return;
    const bin = atob(resultUrl.split(",")[1]);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    downloadBlob(new Blob([arr], { type: `image/${format}` }), `photo-sri-venkateshwara.${format === "jpeg" ? "jpg" : format}`);
  }

  const titleMap: Record<string, string> = {
    resize: "Photo Resize",
    crop: "Photo Crop",
    compress: "Photo Compress",
    enhance: "Photo Enhance",
    bulk: "Bulk Photo Resize",
    rename: "Bulk Photo Rename",
  };

  return (
    <div className="max-w-5xl mx-auto px-4 md:px-6 py-8 md:py-10">
      <div className="mb-8">
        <h1 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">{titleMap[mode] ?? "Photo Resize"}</h1>
        <p className="text-fg/60 mt-1">Resize any photo to exact pixel, mm, cm or inch dimensions with DPI control — instantly, in your browser.</p>
      </div>

      <div className="grid lg:grid-cols-[1fr_340px] gap-6">
        <div className="glass-light rounded-2xl border border-white/10 p-5">
          {!dataUrl ? (
            <div onClick={() => inputRef.current?.click()} className="border-2 border-dashed border-white/15 hover:border-violet/50 rounded-xl p-16 text-center cursor-pointer transition-colors">
              <UploadCloud className="mx-auto mb-2 text-violet" size={28} />
              <p className="text-sm font-medium text-fg">Click to upload a photo</p>
              <p className="text-xs text-fg/40 mt-1">JPG, PNG, WEBP · Max 20MB</p>
              <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
            </div>
          ) : (
            <div className="text-center">
              <p className="text-xs text-fg/50 mb-2">Original: {origSize.w}×{origSize.h}px · {formatBytes(origSize.bytes)}</p>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={resultUrl ?? dataUrl} alt="preview" className="max-h-[420px] mx-auto rounded-xl border border-white/10" />
              {resultUrl && <p className="text-xs text-emerald-400 mt-2">Processed: {formatBytes(resultBytes)}</p>}
              <button onClick={() => { setDataUrl(null); setResultUrl(null); }} className="text-xs text-fg/40 hover:text-red-400 mt-3">Remove &amp; upload another</button>
            </div>
          )}
        </div>

        <div className="glass-light rounded-2xl border border-white/10 p-5 space-y-4 h-fit">
          {mode !== "compress" && (
            <>
              <div className="grid grid-cols-2 gap-2">
                <label className="text-xs text-fg/50">Width
                  <input type="number" value={width} onChange={(e) => onWidthChange(+e.target.value)} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-2 py-1.5 text-fg" />
                </label>
                <label className="text-xs text-fg/50">Height
                  <input type="number" value={height} onChange={(e) => onHeightChange(+e.target.value)} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-2 py-1.5 text-fg" />
                </label>
              </div>
              <label className="text-xs text-fg/50 block">Unit
                <select value={unit} onChange={(e) => setUnit(e.target.value as Unit)} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-2 py-1.5 text-fg">
                  <option value="px" className="bg-surface">Pixels (px)</option>
                  <option value="mm" className="bg-surface">Millimeters (mm)</option>
                  <option value="cm" className="bg-surface">Centimeters (cm)</option>
                  <option value="inch" className="bg-surface">Inches</option>
                </select>
              </label>
              {unit !== "px" && (
                <label className="text-xs text-fg/50 block">DPI
                  <input type="number" value={dpi} onChange={(e) => setDpi(+e.target.value)} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-2 py-1.5 text-fg" />
                </label>
              )}
              <label className="flex items-center gap-2 text-xs text-fg/60">
                <input type="checkbox" checked={lockAspect} onChange={(e) => setLockAspect(e.target.checked)} className="accent-violet" /> Lock aspect ratio
              </label>
            </>
          )}
          <label className="text-xs text-fg/50 block">Output format
            <select value={format} onChange={(e) => setFormat(e.target.value as never)} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-2 py-1.5 text-fg">
              <option value="jpeg" className="bg-surface">JPG</option>
              <option value="png" className="bg-surface">PNG</option>
              <option value="webp" className="bg-surface">WEBP</option>
            </select>
          </label>
          {format !== "png" && (
            <label className="text-xs text-fg/50 block">Quality ({quality}%)
              <input type="range" min={10} max={100} value={quality} onChange={(e) => setQuality(+e.target.value)} className="w-full accent-violet" />
            </label>
          )}
          <button onClick={process} className="w-full py-2.5 rounded-xl font-semibold bg-white/5 hover:bg-white/10 text-fg transition-colors text-sm">Process Image</button>
          <button onClick={download} disabled={!resultUrl} className="w-full inline-flex items-center justify-center gap-2 py-2.5 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity text-sm disabled:opacity-50">
            <Download size={16} /> Download
          </button>
        </div>
      </div>

      {toast && (
        <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 glass px-5 py-3 rounded-xl shadow-xl text-sm text-fg flex items-center gap-2 animate-fade-up">
          {toast}
          <button onClick={() => setToast(null)}><X size={14} /></button>
        </div>
      )}
    </div>
  );
}

export default function PhotoResizePage() {
  return (
    <Suspense fallback={<div className="max-w-5xl mx-auto px-4 py-20 text-center text-fg/50">Loading...</div>}>
      <PhotoResizeInner />
    </Suspense>
  );
}
