export const metadata = { title: "Terms of Service" };

export default function TermsPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 md:px-6 py-14">
      <h1 className="font-[family-name:var(--font-manrope)] text-3xl font-bold text-fg mb-6">Terms of Service</h1>
      <div className="space-y-5 text-fg/70 leading-relaxed text-sm">
        <p>By using Sri Venkateshwara Online Maker, you agree to the following terms.</p>
        <h2 className="text-lg font-semibold text-fg mt-6">Use of Service</h2>
        <p>Our tools are provided for lawful personal, educational, and business use. You are responsible for the content you upload and generate, including ensuring you have the right to use any photos or documents.</p>
        <h2 className="text-lg font-semibold text-fg mt-6">Accuracy of Output</h2>
        <p>While we engineer our print and PDF tools for exact physical accuracy, you should always verify critical documents (such as passport photos for official submission) against the relevant authority&apos;s current requirements before use.</p>
        <h2 className="text-lg font-semibold text-fg mt-6">Plans &amp; Billing</h2>
        <p>Free tools remain free. Pro and Business plan pricing is configurable and displayed on our Pricing page; charges apply only upon explicit subscription.</p>
        <h2 className="text-lg font-semibold text-fg mt-6">Independent Platform</h2>
        <p>Sri Venkateshwara Online Maker is an independent commercial service and is not affiliated with any government agency or department.</p>
        <h2 className="text-lg font-semibold text-fg mt-6">Limitation of Liability</h2>
        <p>The service is provided &quot;as is&quot;. We are not liable for indirect or consequential damages arising from use of the platform.</p>
      </div>
    </div>
  );
}
