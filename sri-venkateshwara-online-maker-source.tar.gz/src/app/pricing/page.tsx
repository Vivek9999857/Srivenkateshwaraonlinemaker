import Link from "next/link";
import { Check } from "lucide-react";

const PLANS = [
  {
    name: "Free",
    price: "₹0",
    period: "forever",
    desc: "Everything a student or individual needs to get started.",
    features: ["Passport photo maker", "Image to PDF & merge PDF", "Standard photo resize", "QR code generator", "Standard export quality"],
    cta: "Start Free",
    highlight: false,
  },
  {
    name: "Pro",
    price: "₹149",
    period: "/month",
    desc: "For power users who need advanced tools and higher limits.",
    features: ["Everything in Free", "Advanced background removal", "Batch processing", "Premium design templates", "Higher upload limits", "Ad-free experience"],
    cta: "Upgrade to Pro",
    highlight: true,
  },
  {
    name: "Business / Cyber Cafe",
    price: "₹499",
    period: "/month",
    desc: "Built for print shops and cyber cafes running daily customer jobs.",
    features: ["Everything in Pro", "Cyber Cafe customer queue", "Unlimited print jobs", "Team member accounts", "Priority support"],
    cta: "Contact Sales",
    highlight: false,
  },
];

export default function PricingPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 md:px-6 py-12 md:py-16">
      <div className="text-center mb-12">
        <h1 className="font-[family-name:var(--font-manrope)] text-3xl md:text-4xl font-bold text-fg">Simple, Transparent Pricing</h1>
        <p className="text-fg/60 mt-3 max-w-xl mx-auto">Choose the plan that fits how you work. Prices shown are illustrative and fully configurable by the platform admin.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {PLANS.map((plan) => (
          <div
            key={plan.name}
            className={`rounded-3xl p-7 border relative flex flex-col ${plan.highlight ? "border-violet gradient-primary text-white shadow-2xl shadow-violet-deep/30 lg:-translate-y-3" : "glass-light border-white/10"}`}
          >
            {plan.highlight && <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-cyan text-ink text-xs font-bold px-3 py-1 rounded-full">MOST POPULAR</span>}
            <h3 className={`font-bold text-lg ${plan.highlight ? "text-white" : "text-fg"}`}>{plan.name}</h3>
            <p className={`text-sm mt-1 ${plan.highlight ? "text-white/80" : "text-fg/55"}`}>{plan.desc}</p>
            <div className="my-5">
              <span className="text-4xl font-extrabold">{plan.price}</span>
              <span className={plan.highlight ? "text-white/70" : "text-fg/50"}> {plan.period}</span>
            </div>
            <ul className="space-y-2.5 flex-1">
              {plan.features.map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm">
                  <Check size={16} className={plan.highlight ? "text-white shrink-0 mt-0.5" : "text-cyan shrink-0 mt-0.5"} />
                  <span className={plan.highlight ? "text-white/90" : "text-fg/70"}>{f}</span>
                </li>
              ))}
            </ul>
            <Link
              href="/login"
              className={`mt-6 text-center py-3 rounded-xl font-semibold transition-colors ${plan.highlight ? "bg-white text-violet-deep hover:bg-white/90" : "bg-white/5 hover:bg-white/10 text-fg"}`}
            >
              {plan.cta}
            </Link>
          </div>
        ))}
      </div>
      <p className="text-center text-xs text-fg/40 mt-10">All plans include secure file handling and automatic temporary-file cleanup. Prices are configurable and may change.</p>
    </div>
  );
}
