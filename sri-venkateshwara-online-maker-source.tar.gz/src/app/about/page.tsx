import { ShieldCheck, Zap, Users, Sparkles } from "lucide-react";
import { LogoMark } from "@/components/Logo";

export const metadata = { title: "About Us" };

const POINTS = [
  { icon: Zap, title: "Fast by design", desc: "Most tools run right in your browser for instant, private results." },
  { icon: ShieldCheck, title: "Security first", desc: "Your files are processed only for the task requested and cleaned up automatically." },
  { icon: Users, title: "Built for India", desc: "From students to cyber cafes, every tool reflects real Indian workflows and paper sizes." },
  { icon: Sparkles, title: "Always improving", desc: "New tools and templates are added regularly based on what our users need most." },
];

export default function AboutPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 md:px-6 py-14">
      <div className="text-center mb-12">
        <div className="flex justify-center mb-4"><LogoMark size={56} /></div>
        <h1 className="font-[family-name:var(--font-manrope)] text-3xl font-bold text-fg">About Sri Venkateshwara Online Maker</h1>
        <p className="text-fg/60 mt-3 max-w-xl mx-auto leading-relaxed">
          We built Sri Venkateshwara Online Maker to be the one place students, cyber cafes, print shops, job applicants and small businesses across India turn to for their everyday digital work — photos, PDFs, ID cards, resumes, designs and printing, done right, every time.
        </p>
      </div>
      <div className="grid sm:grid-cols-2 gap-5">
        {POINTS.map((p) => (
          <div key={p.title} className="glass-light rounded-2xl border border-white/10 p-6">
            <span className="w-11 h-11 rounded-xl gradient-primary flex items-center justify-center mb-3">
              <p.icon size={20} className="text-white" />
            </span>
            <h3 className="font-semibold text-fg mb-1">{p.title}</h3>
            <p className="text-sm text-fg/60 leading-relaxed">{p.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
