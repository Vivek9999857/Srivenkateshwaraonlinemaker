"use client";

import { useState } from "react";
import {
  LayoutDashboard, Users, Wrench, LayoutTemplate, CreditCard, ToggleLeft,
  UploadCloud, Activity, AlertTriangle, Database, Radio, Sparkles, Megaphone,
  HelpCircle, FileText, FolderTree, ShieldCheck
} from "lucide-react";
import { TOOLS } from "@/lib/tools-data";

const NAV = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "users", label: "Users", icon: Users },
  { id: "tools", label: "Tools", icon: Wrench },
  { id: "templates", label: "Templates", icon: LayoutTemplate },
  { id: "pricing", label: "Pricing Plans", icon: CreditCard },
  { id: "features", label: "Feature Toggles", icon: ToggleLeft },
  { id: "limits", label: "Upload Limits", icon: UploadCloud },
  { id: "health", label: "System Health", icon: Activity },
  { id: "errors", label: "Error Logs", icon: AlertTriangle },
  { id: "storage", label: "Storage Usage", icon: Database },
  { id: "api", label: "API Status", icon: Radio },
  { id: "ai", label: "AI Usage", icon: Sparkles },
  { id: "announcements", label: "Announcements", icon: Megaphone },
  { id: "faq", label: "FAQ Management", icon: HelpCircle },
  { id: "content", label: "Homepage Content", icon: FileText },
  { id: "categories", label: "Categories", icon: FolderTree },
];

const STATS = [
  { label: "Total Users", value: "12,480", change: "+8.2%" },
  { label: "Tools Live", value: TOOLS.filter((t) => t.status === "live").length.toString(), change: "" },
  { label: "Jobs Today", value: "3,214", change: "+14%" },
  { label: "Storage Used", value: "42.6 GB", change: "" },
];

export default function AdminDashboardPage() {
  const [active, setActive] = useState("dashboard");
  const [authed, setAuthed] = useState(false);
  const [pass, setPass] = useState("");

  if (!authed) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4">
        <div className="glass-light rounded-3xl border border-white/10 p-8 max-w-sm w-full text-center">
          <ShieldCheck size={32} className="mx-auto text-cyan mb-3" />
          <h1 className="font-semibold text-fg mb-1">Admin Access</h1>
          <p className="text-xs text-fg/50 mb-5">This area is restricted to authorized administrators only.</p>
          <input type="password" value={pass} onChange={(e) => setPass(e.target.value)} placeholder="Admin passcode (demo: admin)" className="w-full bg-transparent border border-white/15 rounded-xl px-4 py-2.5 text-fg text-sm mb-3 focus-ring" />
          <button onClick={() => pass === "admin" ? setAuthed(true) : alert("Incorrect passcode")} className="w-full py-2.5 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity text-sm">
            Enter Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 grid lg:grid-cols-[240px_1fr] gap-6">
      <aside className="glass-light rounded-2xl border border-white/10 p-3 h-fit lg:sticky lg:top-20">
        <p className="px-3 py-2 text-xs font-semibold text-fg/40 uppercase tracking-wide">Admin Panel</p>
        <ul className="space-y-0.5 max-h-[70vh] overflow-y-auto">
          {NAV.map((n) => (
            <li key={n.id}>
              <button onClick={() => setActive(n.id)} className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${active === n.id ? "gradient-primary text-white" : "text-fg/70 hover:bg-white/5"}`}>
                <n.icon size={15} /> {n.label}
              </button>
            </li>
          ))}
        </ul>
      </aside>

      <div>
        <h1 className="font-[family-name:var(--font-manrope)] text-2xl font-bold text-fg mb-6 capitalize">{NAV.find((n) => n.id === active)?.label}</h1>

        {active === "dashboard" && (
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {STATS.map((s) => (
              <div key={s.label} className="glass-light rounded-2xl border border-white/10 p-5">
                <p className="text-xs text-fg/50">{s.label}</p>
                <p className="text-2xl font-bold text-fg mt-1">{s.value}</p>
                {s.change && <p className="text-xs text-emerald-400 mt-1">{s.change} this month</p>}
              </div>
            ))}
          </div>
        )}

        {active === "tools" && (
          <div className="glass-light rounded-2xl border border-white/10 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-fg/50 border-b border-white/10">
                  <th className="p-3">Tool</th><th className="p-3">Category</th><th className="p-3">Status</th><th className="p-3">Action</th>
                </tr>
              </thead>
              <tbody>
                {TOOLS.map((t) => (
                  <tr key={t.id} className="border-b border-white/5">
                    <td className="p-3 text-fg">{t.name}</td>
                    <td className="p-3 text-fg/60 capitalize">{t.category}</td>
                    <td className="p-3">
                      <span className={`text-xs px-2 py-1 rounded-full ${t.status === "live" ? "bg-emerald-500/15 text-emerald-400" : "bg-amber-500/15 text-amber-400"}`}>{t.status}</span>
                    </td>
                    <td className="p-3"><button className="text-xs text-cyan hover:underline">Edit</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {!["dashboard", "tools"].includes(active) && (
          <div className="glass-light rounded-2xl border border-white/10 p-10 text-center text-fg/50">
            <p>The {NAV.find((n) => n.id === active)?.label} panel is available in this admin shell. Connect it to your backend/database to manage live data — never expose private customer files publicly from this panel.</p>
          </div>
        )}
      </div>
    </div>
  );
}
