"use client";

import { useCallback, useMemo, useRef, useState } from "react";
import { jsPDF } from "jspdf";
import {
  UploadCloud, Trash2, Plus, Minus, Printer, Download, FileImage,
  CheckCircle2, RotateCw, Sun, Contrast as ContrastIcon, Droplets, Sparkles, X, Info
} from "lucide-react";
import { PAPER_PRESETS, PHOTO_PRESETS, mmToPx, packSheets, SheetItem, computeGridCapacity } from "@/lib/print-engine";
import { fileToDataUrl, renderPassportPhoto, dataUrlToBlob } from "@/lib/image-ops";
import { downloadBlob, uid, formatBytes } from "@/lib/utils";

interface QueueEntry {
  id: string;
  label: string;
  originalDataUrl: string;
  processedDataUrl: string;
  copies: number;
  photoPresetId: string;
  customWidthMM: number;
  customHeightMM: number;
  brightness: number;
  contrast: number;
  saturation: number;
  rotate: number;
  sharpen: boolean;
  bgColor: string | null;
  borderWidth: number;
  fileSize: number;
}

const ACCEPT = ["image/jpeg", "image/jpg", "image/png", "image/webp"];

export default function PassportPhotoPdfPage() {
  const [queue, setQueue] = useState<QueueEntry[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [paperId, setPaperId] = useState("a4");
  const [customPaperW, setCustomPaperW] = useState(210);
  const [customPaperH, setCustomPaperH] = useState(297);
  const [dpi, setDpi] = useState(300);
  const [marginTop, setMarginTop] = useState(5);
  const [marginBottom, setMarginBottom] = useState(5);
  const [marginLeft, setMarginLeft] = useState(5);
  const [marginRight, setMarginRight] = useState(5);
  const [gapH, setGapH] = useState(2);
  const [gapV, setGapV] = useState(2);
  const [processing, setProcessing] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const paper = useMemo(() => {
    const p = PAPER_PRESETS.find((x) => x.id === paperId)!;
    if (paperId === "custom") return { ...p, widthMM: customPaperW, heightMM: customPaperH };
    return p;
  }, [paperId, customPaperW, customPaperH]);

  const active = queue.find((q) => q.id === activeId) ?? null;

  function showToast(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  }

  const handleFiles = useCallback(async (files: FileList | File[]) => {
    setProcessing(true);
    try {
      const list = Array.from(files);
      const newEntries: QueueEntry[] = [];
      for (const file of list) {
        if (!ACCEPT.includes(file.type)) {
          showToast(`Unsupported format: ${file.name}`);
          continue;
        }
        if (file.size > 15 * 1024 * 1024) {
          showToast(`${file.name} is too large (max 15 MB)`);
          continue;
        }
        try {
          const dataUrl = await fileToDataUrl(file);
          const preset = PHOTO_PRESETS[0];
          newEntries.push({
            id: uid(),
            label: `Customer ${queue.length + newEntries.length + 1}`,
            originalDataUrl: dataUrl,
            processedDataUrl: dataUrl,
            copies: 4,
            photoPresetId: preset.id,
            customWidthMM: preset.widthMM,
            customHeightMM: preset.heightMM,
            brightness: 0,
            contrast: 0,
            saturation: 0,
            rotate: 0,
            sharpen: false,
            bgColor: null,
            borderWidth: 0,
            fileSize: file.size,
          });
        } catch {
          showToast(`Unable to process this image: ${file.name}`);
        }
      }
      if (newEntries.length) {
        setQueue((prev) => [...prev, ...newEntries]);
        setActiveId(newEntries[0].id);
      }
    } finally {
      setProcessing(false);
    }
  }, [queue.length]);

  function updateActive(patch: Partial<QueueEntry>) {
    if (!activeId) return;
    setQueue((prev) => prev.map((q) => (q.id === activeId ? { ...q, ...patch } : q)));
  }

  async function reprocessActive() {
    if (!active) return;
    const preset = PHOTO_PRESETS.find((p) => p.id === active.photoPresetId);
    const wMM = active.photoPresetId === "custom" ? active.customWidthMM : preset?.widthMM ?? 35;
    const hMM = active.photoPresetId === "custom" ? active.customHeightMM : preset?.heightMM ?? 45;
    const outW = mmToPx(wMM, dpi);
    const outH = mmToPx(hMM, dpi);
    try {
      const img = new Image();
      img.src = active.originalDataUrl;
      await new Promise((res) => (img.onload = res));
      const srcAspect = img.width / img.height;
      const targetAspect = wMM / hMM;
      let cropW = img.width, cropH = img.height, cropX = 0, cropY = 0;
      if (srcAspect > targetAspect) {
        cropW = img.height * targetAspect;
        cropX = (img.width - cropW) / 2;
      } else {
        cropH = img.width / targetAspect;
        cropY = (img.height - cropH) / 2;
      }
      const processed = await renderPassportPhoto({
        imageSrc: active.originalDataUrl,
        outWidthPx: outW,
        outHeightPx: outH,
        crop: { x: cropX, y: cropY, width: cropW, height: cropH },
        adjustments: {
          brightness: active.brightness,
          contrast: active.contrast,
          saturation: active.saturation,
          sharpen: active.sharpen,
          rotate: active.rotate,
          bgColor: active.bgColor,
          borderWidth: active.borderWidth,
          borderColor: "#111827",
        },
      });
      updateActive({ processedDataUrl: processed });
    } catch {
      showToast("Unable to process this image. Please try another file.");
    }
  }

  const sheetItems: SheetItem[] = useMemo(() => {
    return queue.map((q) => {
      const preset = PHOTO_PRESETS.find((p) => p.id === q.photoPresetId);
      const wMM = q.photoPresetId === "custom" ? q.customWidthMM : preset?.widthMM ?? 35;
      const hMM = q.photoPresetId === "custom" ? q.customHeightMM : preset?.heightMM ?? 45;
      return {
        id: q.id,
        label: q.label,
        copies: q.copies,
        imageDataUrl: q.processedDataUrl,
        widthMM: wMM,
        heightMM: hMM,
      };
    });
  }, [queue]);

  const pages = useMemo(
    () =>
      packSheets(sheetItems, {
        paperWidthMM: paper.widthMM,
        paperHeightMM: paper.heightMM,
        marginTopMM: marginTop,
        marginBottomMM: marginBottom,
        marginLeftMM: marginLeft,
        marginRightMM: marginRight,
        gapHMM: gapH,
        gapVMM: gapV,
        dpi,
      }),
    [sheetItems, paper, marginTop, marginBottom, marginLeft, marginRight, gapH, gapV, dpi]
  );

  const totalCopies = queue.reduce((sum, q) => sum + q.copies, 0);

  async function renderPageToCanvas(page: (typeof pages)[number], scale = 1): Promise<HTMLCanvasElement> {
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(mmToPx(paper.widthMM, dpi) * scale);
    canvas.height = Math.round(mmToPx(paper.heightMM, dpi) * scale);
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    for (const photo of page.photos) {
      const img = new Image();
      img.src = photo.imageDataUrl;
      await new Promise((res) => (img.onload = res));
      const x = mmToPx(photo.xMM, dpi) * scale;
      const y = mmToPx(photo.yMM, dpi) * scale;
      const w = mmToPx(photo.widthMM, dpi) * scale;
      const h = mmToPx(photo.heightMM, dpi) * scale;
      ctx.drawImage(img, x, y, w, h);
    }
    return canvas;
  }

  async function handleDownloadPDF() {
    if (pages.length === 0) return showToast("Add at least one photo first.");
    setProcessing(true);
    try {
      const pdf = new jsPDF({
        orientation: paper.widthMM > paper.heightMM ? "landscape" : "portrait",
        unit: "mm",
        format: [paper.widthMM, paper.heightMM],
      });
      for (let i = 0; i < pages.length; i++) {
        if (i > 0) pdf.addPage([paper.widthMM, paper.heightMM]);
        const canvas = await renderPageToCanvas(pages[i]);
        const imgData = canvas.toDataURL("image/jpeg", 0.95);
        pdf.addImage(imgData, "JPEG", 0, 0, paper.widthMM, paper.heightMM);
      }
      pdf.save("passport-photos-sri-venkateshwara.pdf");
      showToast("PDF downloaded successfully.");
    } catch {
      showToast("We couldn't generate the PDF. Please try again.");
    } finally {
      setProcessing(false);
    }
  }

  async function handleDownloadImage(format: "jpg" | "png") {
    if (pages.length === 0) return showToast("Add at least one photo first.");
    setProcessing(true);
    try {
      for (let i = 0; i < pages.length; i++) {
        const canvas = await renderPageToCanvas(pages[i], 2);
        const mime = format === "jpg" ? "image/jpeg" : "image/png";
        const dataUrl = canvas.toDataURL(mime, 0.95);
        downloadBlob(dataUrlToBlob(dataUrl), `passport-sheet-${i + 1}.${format}`);
      }
      showToast(`${format.toUpperCase()} downloaded successfully.`);
    } catch {
      showToast("We couldn't export the image. Please try again.");
    } finally {
      setProcessing(false);
    }
  }

  async function handlePrint() {
    if (pages.length === 0) return showToast("Add at least one photo first.");
    const win = window.open("", "_blank");
    if (!win) return showToast("Please allow pop-ups to print.");
    win.document.write(`<html><head><title>Print - Sri Venkateshwara Online Maker</title>
      <style>@page{size:${paper.widthMM}mm ${paper.heightMM}mm;margin:0} body{margin:0} img{width:100%;display:block;page-break-after:always}</style>
      </head><body></body></html>`);
    win.document.close();
    for (const page of pages) {
      const canvas = await renderPageToCanvas(page, 2);
      const img = win.document.createElement("img");
      img.src = canvas.toDataURL("image/jpeg", 0.98);
      win.document.body.appendChild(img);
    }
    setTimeout(() => win.print(), 500);
  }

  const activePreset = active ? PHOTO_PRESETS.find((p) => p.id === active.photoPresetId) : null;
  const activeWmm = active ? (active.photoPresetId === "custom" ? active.customWidthMM : activePreset?.widthMM ?? 35) : 35;
  const activeHmm = active ? (active.photoPresetId === "custom" ? active.customHeightMM : activePreset?.heightMM ?? 45) : 45;
  const gridCap = computeGridCapacity(
    paper.widthMM, paper.heightMM, activeWmm, activeHmm,
    { top: marginTop, bottom: marginBottom, left: marginLeft, right: marginRight }, gapH, gapV
  );

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-10">
      <div className="mb-8">
        <span className="inline-block px-3 py-1 rounded-full bg-violet/15 text-violet text-xs font-semibold mb-2">FLAGSHIP TOOL</span>
        <h1 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">Passport Photo PDF Generator</h1>
        <p className="text-fg/60 mt-1">Upload multiple customers&apos; photos, set copies for each, and print them all on one print-ready sheet with exact mm/DPI accuracy.</p>
      </div>

      <div className="grid lg:grid-cols-[340px_1fr] gap-6">
        {/* LEFT: Controls */}
        <div className="space-y-5">
          {/* Step 1: Upload */}
          <div className="glass-light rounded-2xl border border-white/10 p-5">
            <h2 className="font-semibold text-fg mb-3 flex items-center gap-2"><span className="w-6 h-6 rounded-full gradient-primary text-white text-xs flex items-center justify-center">1</span>Upload Photos</h2>
            <div
              onClick={() => fileInputRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => { e.preventDefault(); if (e.dataTransfer.files.length) handleFiles(e.dataTransfer.files); }}
              className="border-2 border-dashed border-white/15 hover:border-violet/50 rounded-xl p-6 text-center cursor-pointer transition-colors"
            >
              <UploadCloud className="mx-auto mb-2 text-violet" size={28} />
              <p className="text-sm font-medium text-fg">Drag & drop or click to upload</p>
              <p className="text-xs text-fg/40 mt-1">JPG, JPEG, PNG, WEBP · Max 15MB each</p>
              <input ref={fileInputRef} type="file" multiple accept={ACCEPT.join(",")} className="hidden" onChange={(e) => e.target.files && handleFiles(e.target.files)} />
            </div>

            {queue.length > 0 && (
              <ul className="mt-4 space-y-2 max-h-56 overflow-y-auto pr-1">
                {queue.map((q) => (
                  <li
                    key={q.id}
                    onClick={() => setActiveId(q.id)}
                    className={`flex items-center gap-3 p-2 rounded-xl cursor-pointer border transition-colors ${activeId === q.id ? "border-cyan bg-cyan/5" : "border-white/10 hover:bg-white/5"}`}
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={q.processedDataUrl} alt={q.label} className="w-10 h-12 object-cover rounded-md bg-black/20" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-fg truncate">{q.label}</p>
                      <p className="text-xs text-fg/45">{q.copies} copies · {formatBytes(q.fileSize)}</p>
                    </div>
                    <button onClick={(e) => { e.stopPropagation(); setQueue((prev) => prev.filter((x) => x.id !== q.id)); if (activeId === q.id) setActiveId(null); }} className="p-1.5 rounded-lg hover:bg-red-500/15 text-fg/40 hover:text-red-400">
                      <Trash2 size={14} />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {active && (
            <>
              {/* Step 2: Size */}
              <div className="glass-light rounded-2xl border border-white/10 p-5">
                <h2 className="font-semibold text-fg mb-3 flex items-center gap-2"><span className="w-6 h-6 rounded-full gradient-primary text-white text-xs flex items-center justify-center">2</span>Photo Size</h2>
                <select
                  value={active.photoPresetId}
                  onChange={(e) => updateActive({ photoPresetId: e.target.value })}
                  className="w-full bg-transparent border border-white/15 rounded-lg px-3 py-2 text-sm text-fg mb-3 focus-ring"
                >
                  {PHOTO_PRESETS.map((p) => (
                    <option key={p.id} value={p.id} className="bg-surface">{p.label}</option>
                  ))}
                </select>
                {active.photoPresetId === "custom" && (
                  <div className="grid grid-cols-2 gap-2">
                    <label className="text-xs text-fg/50">Width (mm)
                      <input type="number" value={active.customWidthMM} onChange={(e) => updateActive({ customWidthMM: +e.target.value })} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-2 py-1.5 text-fg" />
                    </label>
                    <label className="text-xs text-fg/50">Height (mm)
                      <input type="number" value={active.customHeightMM} onChange={(e) => updateActive({ customHeightMM: +e.target.value })} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-2 py-1.5 text-fg" />
                    </label>
                  </div>
                )}
                <label className="block text-xs text-fg/50 mt-3">Customer / Label name
                  <input value={active.label} onChange={(e) => updateActive({ label: e.target.value })} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-2 py-1.5 text-fg text-sm" />
                </label>
              </div>

              {/* Step 3: Adjustments */}
              <div className="glass-light rounded-2xl border border-white/10 p-5">
                <h2 className="font-semibold text-fg mb-3 flex items-center gap-2"><span className="w-6 h-6 rounded-full gradient-primary text-white text-xs flex items-center justify-center">3</span>Adjustments</h2>
                <div className="space-y-3">
                  <AdjustSlider icon={Sun} label="Brightness" value={active.brightness} onChange={(v) => updateActive({ brightness: v })} />
                  <AdjustSlider icon={ContrastIcon} label="Contrast" value={active.contrast} onChange={(v) => updateActive({ contrast: v })} />
                  <AdjustSlider icon={Droplets} label="Saturation" value={active.saturation} onChange={(v) => updateActive({ saturation: v })} />
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-2 text-sm text-fg/70"><RotateCw size={14} /> Rotate</span>
                    <div className="flex items-center gap-2">
                      <button onClick={() => updateActive({ rotate: active.rotate - 90 })} className="px-2 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-xs">-90°</button>
                      <button onClick={() => updateActive({ rotate: active.rotate + 90 })} className="px-2 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-xs">+90°</button>
                    </div>
                  </div>
                  <label className="flex items-center justify-between text-sm text-fg/70 cursor-pointer">
                    <span className="flex items-center gap-2"><Sparkles size={14} /> Sharpen</span>
                    <input type="checkbox" checked={active.sharpen} onChange={(e) => updateActive({ sharpen: e.target.checked })} className="accent-violet w-4 h-4" />
                  </label>
                  <div>
                    <span className="text-sm text-fg/70">Background color</span>
                    <div className="flex gap-2 mt-1.5">
                      {["#FFFFFF", "#E5E7EB", "#60A5FA", "#F87171", null].map((c, i) => (
                        <button
                          key={i}
                          onClick={() => updateActive({ bgColor: c })}
                          className={`w-7 h-7 rounded-full border-2 ${active.bgColor === c ? "border-cyan" : "border-white/20"}`}
                          style={{ background: c ?? "repeating-conic-gradient(#999 0% 25%, #ccc 0% 50%) 50%/10px 10px" }}
                          aria-label={c ?? "None"}
                        />
                      ))}
                    </div>
                  </div>
                  <label className="text-xs text-fg/50 block">Border width (px)
                    <input type="range" min={0} max={12} value={active.borderWidth} onChange={(e) => updateActive({ borderWidth: +e.target.value })} className="w-full accent-violet" />
                  </label>
                  <button onClick={reprocessActive} className="w-full mt-1 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-sm font-semibold text-fg transition-colors">
                    Apply Adjustments
                  </button>
                </div>
              </div>

              {/* Step 3b: Copies */}
              <div className="glass-light rounded-2xl border border-white/10 p-5">
                <h2 className="font-semibold text-fg mb-3">Copies for {active.label}</h2>
                <div className="flex items-center justify-center gap-4">
                  <button onClick={() => updateActive({ copies: Math.max(1, active.copies - 1) })} className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center">
                    <Minus size={16} />
                  </button>
                  <span className="text-2xl font-bold text-fg w-12 text-center">{active.copies}</span>
                  <button onClick={() => updateActive({ copies: active.copies + 1 })} className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center">
                    <Plus size={16} />
                  </button>
                </div>
              </div>
            </>
          )}

          {/* Step 4: Paper */}
          <div className="glass-light rounded-2xl border border-white/10 p-5">
            <h2 className="font-semibold text-fg mb-3 flex items-center gap-2"><span className="w-6 h-6 rounded-full gradient-primary text-white text-xs flex items-center justify-center">4</span>Paper & Layout</h2>
            <select value={paperId} onChange={(e) => setPaperId(e.target.value)} className="w-full bg-transparent border border-white/15 rounded-lg px-3 py-2 text-sm text-fg mb-3 focus-ring">
              {PAPER_PRESETS.map((p) => <option key={p.id} value={p.id} className="bg-surface">{p.label}</option>)}
            </select>
            {paperId === "custom" && (
              <div className="grid grid-cols-2 gap-2 mb-3">
                <label className="text-xs text-fg/50">Width (mm)
                  <input type="number" value={customPaperW} onChange={(e) => setCustomPaperW(+e.target.value)} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-2 py-1.5 text-fg" />
                </label>
                <label className="text-xs text-fg/50">Height (mm)
                  <input type="number" value={customPaperH} onChange={(e) => setCustomPaperH(+e.target.value)} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-2 py-1.5 text-fg" />
                </label>
              </div>
            )}
            <div className="grid grid-cols-2 gap-2 mb-2">
              <NumField label="Top margin (mm)" value={marginTop} onChange={setMarginTop} />
              <NumField label="Bottom margin (mm)" value={marginBottom} onChange={setMarginBottom} />
              <NumField label="Left margin (mm)" value={marginLeft} onChange={setMarginLeft} />
              <NumField label="Right margin (mm)" value={marginRight} onChange={setMarginRight} />
              <NumField label="Horizontal gap (mm)" value={gapH} onChange={setGapH} />
              <NumField label="Vertical gap (mm)" value={gapV} onChange={setGapV} />
            </div>
            <label className="text-xs text-fg/50 block mt-2">DPI
              <select value={dpi} onChange={(e) => setDpi(+e.target.value)} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-2 py-1.5 text-fg">
                {[150, 200, 300, 600].map((d) => <option key={d} value={d} className="bg-surface">{d} DPI</option>)}
              </select>
            </label>
            {active && (
              <p className="mt-3 text-xs text-fg/45 flex items-center gap-1.5">
                <Info size={12} /> Fits up to {gridCap.total} photos ({gridCap.cols}×{gridCap.rows}) per sheet at this size.
              </p>
            )}
          </div>
        </div>

        {/* RIGHT: Preview + Actions */}
        <div className="space-y-5">
          <div className="glass-light rounded-2xl border border-white/10 p-5">
            <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
              <div>
                <h2 className="font-semibold text-fg">Real-Time Print Preview</h2>
                <p className="text-xs text-fg/45">{pages.length} page{pages.length !== 1 ? "s" : ""} · {totalCopies} photo{totalCopies !== 1 ? "s" : ""} total · {paper.label}</p>
              </div>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-400 text-xs font-semibold">
                <CheckCircle2 size={13} /> Print Ready
              </span>
            </div>

            {queue.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <FileImage size={40} className="text-fg/20 mb-3" />
                <p className="text-fg/50">Upload photos to see the actual-size print preview here.</p>
              </div>
            ) : (
              <div className="space-y-6 max-h-[640px] overflow-y-auto pr-1">
                {pages.map((page, pi) => {
                  const aspect = paper.widthMM / paper.heightMM;
                  return (
                    <div key={pi} className="mx-auto" style={{ maxWidth: 420 }}>
                      <p className="text-xs text-fg/40 mb-1.5 text-center">Sheet {pi + 1} of {pages.length} — Actual Size {paper.widthMM}×{paper.heightMM}mm</p>
                      <div
                        className="relative bg-white rounded-lg shadow-xl mx-auto overflow-hidden"
                        style={{ width: "100%", aspectRatio: `${aspect}` }}
                      >
                        {page.photos.map((ph, idx) => (
                          <div
                            key={idx}
                            className="absolute overflow-hidden"
                            style={{
                              left: `${(ph.xMM / paper.widthMM) * 100}%`,
                              top: `${(ph.yMM / paper.heightMM) * 100}%`,
                              width: `${(ph.widthMM / paper.widthMM) * 100}%`,
                              height: `${(ph.heightMM / paper.heightMM) * 100}%`,
                            }}
                          >
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img src={ph.imageDataUrl} alt="" className="w-full h-full object-cover" />
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="glass-light rounded-2xl border border-white/10 p-5">
            <h3 className="font-semibold text-fg mb-3">Step 7 — Export</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <ActionBtn icon={Download} label="PDF" onClick={handleDownloadPDF} primary disabled={processing} />
              <ActionBtn icon={FileImage} label="JPG" onClick={() => handleDownloadImage("jpg")} disabled={processing} />
              <ActionBtn icon={FileImage} label="PNG" onClick={() => handleDownloadImage("png")} disabled={processing} />
              <ActionBtn icon={Printer} label="Print" onClick={handlePrint} disabled={processing} />
            </div>
            <p className="text-xs text-fg/40 mt-3">PDF preserves exact physical dimensions ({paper.widthMM}×{paper.heightMM}mm) at {dpi} DPI.</p>
          </div>
        </div>
      </div>

      {toast && (
        <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 glass px-5 py-3 rounded-xl shadow-xl text-sm text-fg flex items-center gap-2 animate-fade-up">
          {toast}
          <button onClick={() => setToast(null)}><X size={14} /></button>
        </div>
      )}
    </div>
  );
}

function AdjustSlider({ icon: Icon, label, value, onChange }: { icon: React.ElementType; label: string; value: number; onChange: (v: number) => void }) {
  return (
    <label className="block">
      <span className="flex items-center justify-between text-sm text-fg/70 mb-1">
        <span className="flex items-center gap-2"><Icon size={14} /> {label}</span>
        <span className="text-xs text-fg/40">{value}</span>
      </span>
      <input type="range" min={-100} max={100} value={value} onChange={(e) => onChange(+e.target.value)} className="w-full accent-violet" />
    </label>
  );
}

function NumField({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <label className="text-xs text-fg/50">
      {label}
      <input type="number" step={0.5} value={value} onChange={(e) => onChange(+e.target.value)} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-2 py-1.5 text-fg" />
    </label>
  );
}

function ActionBtn({ icon: Icon, label, onClick, primary, disabled }: { icon: React.ElementType; label: string; onClick: () => void; primary?: boolean; disabled?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`flex flex-col items-center gap-1.5 py-3.5 rounded-xl font-semibold text-sm transition-all disabled:opacity-50 ${
        primary ? "gradient-primary text-white hover:opacity-90" : "bg-white/5 hover:bg-white/10 text-fg"
      }`}
    >
      <Icon size={18} />
      {label}
    </button>
  );
}
