"use client";

import { useMemo, useRef, useState } from "react";
import html2canvas from "html2canvas";
import { jsPDF } from "jspdf";
import { Download, Plus, Trash2, Printer, X } from "lucide-react";
import { downloadBlob } from "@/lib/utils";

interface Experience { id: string; role: string; company: string; period: string; details: string }
interface Education { id: string; degree: string; school: string; period: string }

const TEMPLATES = ["Professional", "Fresher", "ATS-Friendly", "Experienced"] as const;

export default function ResumeMakerPage() {
  const [template, setTemplate] = useState<(typeof TEMPLATES)[number]>("Professional");
  const [name, setName] = useState("Your Full Name");
  const [role, setRole] = useState("Aspiring Software Developer");
  const [email, setEmail] = useState("you@email.com");
  const [phone, setPhone] = useState("+91 90000 00000");
  const [address, setAddress] = useState("Bengaluru, India");
  const [summary, setSummary] = useState("Motivated and detail-oriented professional with strong problem-solving skills, seeking to contribute to a growth-focused organization.");
  const [skills, setSkills] = useState("Communication, MS Office, Teamwork, Time Management");
  const [experiences, setExperiences] = useState<Experience[]>([
    { id: "1", role: "Intern", company: "ABC Pvt Ltd", period: "Jun 2024 – Dec 2024", details: "Assisted in daily operations and supported the team with reports and documentation." },
  ]);
  const [education, setEducation] = useState<Education[]>([
    { id: "1", degree: "B.Com", school: "XYZ College", period: "2021 – 2024" },
  ]);
  const [toast, setToast] = useState<string | null>(null);
  const previewRef = useRef<HTMLDivElement>(null);

  function notify(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  }

  const skillList = useMemo(() => skills.split(",").map((s) => s.trim()).filter(Boolean), [skills]);

  function addExperience() {
    setExperiences((prev) => [...prev, { id: Date.now().toString(), role: "", company: "", period: "", details: "" }]);
  }
  function addEducation() {
    setEducation((prev) => [...prev, { id: Date.now().toString(), degree: "", school: "", period: "" }]);
  }

  async function exportPdf() {
    if (!previewRef.current) return;
    try {
      const canvas = await html2canvas(previewRef.current, { scale: 2, backgroundColor: "#ffffff" });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF({ unit: "mm", format: "a4" });
      const pageW = 210, pageH = 297;
      const imgH = (canvas.height * pageW) / canvas.width;
      pdf.addImage(imgData, "PNG", 0, 0, pageW, Math.min(imgH, pageH));
      pdf.save("resume-sri-venkateshwara.pdf");
      notify("Resume PDF downloaded successfully.");
    } catch {
      notify("We couldn't export the resume. Please try again.");
    }
  }

  async function downloadPng() {
    if (!previewRef.current) return;
    try {
      const canvas = await html2canvas(previewRef.current, { scale: 2, backgroundColor: "#ffffff" });
      canvas.toBlob((blob) => blob && downloadBlob(blob, "resume-sri-venkateshwara.png"));
    } catch {
      notify("We couldn't export the image. Please try again.");
    }
  }

  function handlePrint() {
    window.print();
  }

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-10">
      <div className="mb-8">
        <h1 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">Resume Maker</h1>
        <p className="text-fg/60 mt-1">Build a professional, ATS-friendly resume with a live preview — export as PDF, PNG or print directly.</p>
      </div>

      <div className="grid lg:grid-cols-[380px_1fr] gap-6">
        <div className="space-y-5">
          <div className="glass-light rounded-2xl border border-white/10 p-5">
            <h2 className="font-semibold text-fg mb-3 text-sm">Template</h2>
            <div className="grid grid-cols-2 gap-2">
              {TEMPLATES.map((t) => (
                <button key={t} onClick={() => setTemplate(t)} className={`py-2.5 rounded-xl text-xs font-semibold transition-colors ${template === t ? "gradient-primary text-white" : "bg-white/5 hover:bg-white/10 text-fg/70"}`}>
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div className="glass-light rounded-2xl border border-white/10 p-5 space-y-3">
            <h2 className="font-semibold text-fg text-sm">Personal Details</h2>
            <Field label="Full Name" value={name} onChange={setName} />
            <Field label="Target Role" value={role} onChange={setRole} />
            <Field label="Email" value={email} onChange={setEmail} />
            <Field label="Phone" value={phone} onChange={setPhone} />
            <Field label="Address" value={address} onChange={setAddress} />
            <TextArea label="Professional Summary" value={summary} onChange={setSummary} />
            <Field label="Skills (comma separated)" value={skills} onChange={setSkills} />
          </div>

          <div className="glass-light rounded-2xl border border-white/10 p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-fg text-sm">Experience</h2>
              <button onClick={addExperience} className="text-xs text-cyan flex items-center gap-1"><Plus size={13} /> Add</button>
            </div>
            {experiences.map((exp, i) => (
              <div key={exp.id} className="border border-white/10 rounded-xl p-3 space-y-2 relative">
                <button onClick={() => setExperiences((prev) => prev.filter((e) => e.id !== exp.id))} className="absolute top-2 right-2 text-fg/30 hover:text-red-400"><Trash2 size={13} /></button>
                <Field label="Role" value={exp.role} onChange={(v) => setExperiences((prev) => prev.map((e, idx) => idx === i ? { ...e, role: v } : e))} />
                <Field label="Company" value={exp.company} onChange={(v) => setExperiences((prev) => prev.map((e, idx) => idx === i ? { ...e, company: v } : e))} />
                <Field label="Period" value={exp.period} onChange={(v) => setExperiences((prev) => prev.map((e, idx) => idx === i ? { ...e, period: v } : e))} />
                <TextArea label="Details" value={exp.details} onChange={(v) => setExperiences((prev) => prev.map((e, idx) => idx === i ? { ...e, details: v } : e))} />
              </div>
            ))}
          </div>

          <div className="glass-light rounded-2xl border border-white/10 p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-fg text-sm">Education</h2>
              <button onClick={addEducation} className="text-xs text-cyan flex items-center gap-1"><Plus size={13} /> Add</button>
            </div>
            {education.map((edu, i) => (
              <div key={edu.id} className="border border-white/10 rounded-xl p-3 space-y-2 relative">
                <button onClick={() => setEducation((prev) => prev.filter((e) => e.id !== edu.id))} className="absolute top-2 right-2 text-fg/30 hover:text-red-400"><Trash2 size={13} /></button>
                <Field label="Degree" value={edu.degree} onChange={(v) => setEducation((prev) => prev.map((e, idx) => idx === i ? { ...e, degree: v } : e))} />
                <Field label="School / College" value={edu.school} onChange={(v) => setEducation((prev) => prev.map((e, idx) => idx === i ? { ...e, school: v } : e))} />
                <Field label="Period" value={edu.period} onChange={(v) => setEducation((prev) => prev.map((e, idx) => idx === i ? { ...e, period: v } : e))} />
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="flex flex-wrap gap-3 mb-4">
            <button onClick={exportPdf} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity text-sm">
              <Download size={16} /> Download PDF
            </button>
            <button onClick={downloadPng} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold bg-white/5 hover:bg-white/10 text-fg transition-colors text-sm">
              <Download size={16} /> Download PNG
            </button>
            <button onClick={handlePrint} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold bg-white/5 hover:bg-white/10 text-fg transition-colors text-sm">
              <Printer size={16} /> Print
            </button>
          </div>

          <div className="glass-light rounded-2xl border border-white/10 p-4 md:p-6 overflow-x-auto">
            <div id="print-area" ref={previewRef} className="bg-white text-ink w-[210mm] min-h-[297mm] mx-auto p-10 shadow-xl" style={{ fontFamily: "Georgia, serif" }}>
              <div className="border-b-4 pb-4 mb-5" style={{ borderColor: "#6D28D9" }}>
                <h1 className="text-3xl font-bold" style={{ color: "#111827" }}>{name}</h1>
                <p className="text-lg" style={{ color: "#6D28D9" }}>{role}</p>
                <p className="text-sm text-gray-600 mt-1">{email} · {phone} · {address}</p>
              </div>
              <Section title="Professional Summary">
                <p className="text-sm text-gray-700 leading-relaxed">{summary}</p>
              </Section>
              <Section title="Skills">
                <div className="flex flex-wrap gap-2">
                  {skillList.map((s) => (
                    <span key={s} className="text-xs px-2.5 py-1 rounded-full" style={{ background: "#EDE9FE", color: "#6D28D9" }}>{s}</span>
                  ))}
                </div>
              </Section>
              <Section title="Experience">
                <div className="space-y-3">
                  {experiences.map((exp) => (
                    <div key={exp.id}>
                      <div className="flex justify-between text-sm font-semibold text-gray-800">
                        <span>{exp.role} · {exp.company}</span>
                        <span className="text-gray-500 font-normal">{exp.period}</span>
                      </div>
                      <p className="text-sm text-gray-600 mt-0.5">{exp.details}</p>
                    </div>
                  ))}
                </div>
              </Section>
              <Section title="Education">
                <div className="space-y-2">
                  {education.map((edu) => (
                    <div key={edu.id} className="flex justify-between text-sm text-gray-700">
                      <span className="font-semibold">{edu.degree}, {edu.school}</span>
                      <span className="text-gray-500">{edu.period}</span>
                    </div>
                  ))}
                </div>
              </Section>
            </div>
          </div>
        </div>
      </div>

      {toast && (
        <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 glass px-5 py-3 rounded-xl shadow-xl text-sm text-fg flex items-center gap-2 animate-fade-up">
          {toast}
          <button onClick={() => setToast(null)}><X size={14} /></button>
        </div>
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-5">
      <h2 className="text-sm font-bold uppercase tracking-wide mb-2" style={{ color: "#6D28D9" }}>{title}</h2>
      {children}
    </div>
  );
}
function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="text-xs text-fg/50 block">
      {label}
      <input value={value} onChange={(e) => onChange(e.target.value)} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-3 py-2 text-fg text-sm" />
    </label>
  );
}
function TextArea({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="text-xs text-fg/50 block">
      {label}
      <textarea value={value} onChange={(e) => onChange(e.target.value)} rows={3} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-3 py-2 text-fg text-sm" />
    </label>
  );
}
