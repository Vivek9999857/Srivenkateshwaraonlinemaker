export const metadata = { title: "Privacy Policy" };

export default function PrivacyPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 md:px-6 py-14 prose-content">
      <h1 className="font-[family-name:var(--font-manrope)] text-3xl font-bold text-fg mb-6">Privacy Policy</h1>
      <div className="space-y-5 text-fg/70 leading-relaxed text-sm">
        <p>Sri Venkateshwara Online Maker (&quot;we&quot;, &quot;our&quot;, &quot;the platform&quot;) respects your privacy. This policy explains how we handle files and information you provide while using our tools.</p>
        <h2 className="text-lg font-semibold text-fg mt-6">File Processing</h2>
        <p>Files are processed only for the requested task and temporary files are automatically removed according to the configured retention policy. Many tools process files entirely within your browser and never transmit them to a server.</p>
        <h2 className="text-lg font-semibold text-fg mt-6">No Public File URLs</h2>
        <p>We never expose your uploaded files or generated documents through public URLs. Access is restricted and time-limited where server processing is used.</p>
        <h2 className="text-lg font-semibold text-fg mt-6">Data We Collect</h2>
        <p>For account holders, we may store your email, saved projects, templates, and download history to provide the service. Guest usage of browser-based tools does not require an account.</p>
        <h2 className="text-lg font-semibold text-fg mt-6">Security</h2>
        <p>We use HTTPS, input validation, rate limiting, and access controls to protect your data. Administrators cannot access your private files through the public interface.</p>
        <h2 className="text-lg font-semibold text-fg mt-6">Not a Government Service</h2>
        <p>Sri Venkateshwara Online Maker is an independent commercial platform. We are not affiliated with, endorsed by, or certified by any government body.</p>
        <h2 className="text-lg font-semibold text-fg mt-6">Contact</h2>
        <p>For privacy questions, please use our Help Center to report an issue.</p>
      </div>
    </div>
  );
}
