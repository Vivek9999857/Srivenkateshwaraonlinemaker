"use client";

import { Suspense, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import html2canvas from "html2canvas";
import QRCode from "qrcode";
import { UploadCloud, Download, Printer, X, RotateCw } from "lucide-react";
import { fileToDataUrl } from "@/lib/image-ops";
import { downloadBlob } from "@/lib/utils";

const TEMPLATES = [
  { id: "school", label: "School / College ID", color: "#2563EB" },
  { id: "employee", label: "Employee ID", color: "#6D28D9" },
  { id: "event", label: "Event ID", color: "#06B6D4" },
  { id: "custom", label: "Custom", color: "#111827" },
];

function IdCardInner() {
  const params = useSearchParams();
  const initialTemplate = params.get("template") || "employee";
  const [template, setTemplate] = useState(initialTemplate);
  const [side, setSide] = useState<"front" | "back">("front");
  const [photo, setPhoto] = useState<string | null>(null);
  const [name, setName] = useState("Full Name");
  const [role, setRole] = useState("Designation / Class");
  const [org, setOrg] = useState("Organization Name");
  const [idNumber, setIdNumber] = useState("ID-0001");
  const [validTill, setValidTill] = useState("12/2026");
  const [backText, setBackText] = useState("If found, please return to the address below.\n123 Main Street, Bengaluru, Karnataka");
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const tpl = TEMPLATES.find((t) => t.id === template) ?? TEMPLATES[1];

  function notify(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  }

  async function handlePhoto(f: File) {
    if (!["image/jpeg", "image/png", "image/webp"].includes(f.type)) return notify("Unsupported format.");
    try {
      setPhoto(await fileToDataUrl(f));
    } catch {
      notify("Unable to process this image.");
    }
  }

  async function genQr() {
    try {
      const val = `ID:${idNumber}\nName:${name}\nOrg:${org}`;
      const url = await QRCode.toDataURL(val, { width: 200, margin: 1 });
      setQrDataUrl(url);
      notify("QR code generated.");
    } catch {
      notify("Unable to generate QR code.");
    }
  }

  async function downloadPng() {
    if (!cardRef.current) return;
    try {
      const canvas = await html2canvas(cardRef.current, { scale: 3, backgroundColor: "#ffffff" });
      canvas.toBlob((b) => b && downloadBlob(b, `id-card-${side}.png`));
    } catch {
      notify("Unable to export card. Please try again.");
    }
  }

  return (
    <div className="max-w-6xl mx-auto px-4 md:px-6 py-8 md:py-10">
      <div className="mb-8">
        <h1 className="font-[family-name:var(--font-manrope)] text-2xl md:text-3xl font-bold text-fg">ID Card Maker</h1>
        <p className="text-fg/60 mt-1">Design front and back ID cards with photo, text, and QR code — export print-ready PNG.</p>
      </div>

      <div className="grid lg:grid-cols-[340px_1fr] gap-6">
        <div className="space-y-5">
          <div className="glass-light rounded-2xl border border-white/10 p-5">
            <h2 className="font-semibold text-fg mb-3 text-sm">Template</h2>
            <div className="grid grid-cols-2 gap-2">
              {TEMPLATES.map((t) => (
                <button key={t.id} onClick={() => setTemplate(t.id)} className={`py-2.5 rounded-xl text-xs font-semibold transition-colors ${template === t.id ? "gradient-primary text-white" : "bg-white/5 hover:bg-white/10 text-fg/70"}`}>
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          <div className="glass-light rounded-2xl border border-white/10 p-5 space-y-3">
            <h2 className="font-semibold text-fg text-sm">Photo</h2>
            <div onClick={() => inputRef.current?.click()} className="border-2 border-dashed border-white/15 hover:border-violet/50 rounded-xl p-5 text-center cursor-pointer">
              <UploadCloud className="mx-auto mb-1 text-violet" size={22} />
              <p className="text-xs text-fg/60">Upload photo</p>
              <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handlePhoto(e.target.files[0])} />
            </div>
          </div>

          <div className="glass-light rounded-2xl border border-white/10 p-5 space-y-3">
            <h2 className="font-semibold text-fg text-sm">Front Details</h2>
            <Field label="Full Name" value={name} onChange={setName} />
            <Field label="Role / Class" value={role} onChange={setRole} />
            <Field label="Organization" value={org} onChange={setOrg} />
            <Field label="ID Number" value={idNumber} onChange={setIdNumber} />
            <Field label="Valid Till" value={validTill} onChange={setValidTill} />
            <button onClick={genQr} className="w-full py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-fg">Generate QR Code</button>
          </div>

          <div className="glass-light rounded-2xl border border-white/10 p-5 space-y-3">
            <h2 className="font-semibold text-fg text-sm">Back Side Text</h2>
            <textarea value={backText} onChange={(e) => setBackText(e.target.value)} rows={4} className="w-full bg-transparent border border-white/15 rounded-lg px-3 py-2 text-fg text-sm" />
          </div>
        </div>

        <div>
          <div className="flex items-center gap-3 mb-4">
            <button onClick={() => setSide("front")} className={`px-4 py-2 rounded-xl text-sm font-semibold ${side === "front" ? "gradient-primary text-white" : "bg-white/5 text-fg/70"}`}>Front</button>
            <button onClick={() => setSide("back")} className={`px-4 py-2 rounded-xl text-sm font-semibold ${side === "back" ? "gradient-primary text-white" : "bg-white/5 text-fg/70"}`}>Back</button>
            <button onClick={() => setSide((s) => (s === "front" ? "back" : "front"))} className="ml-auto p-2 rounded-xl bg-white/5 hover:bg-white/10 text-fg/60"><RotateCw size={16} /></button>
          </div>

          <div className="glass-light rounded-2xl border border-white/10 p-8 flex justify-center">
            <div
              ref={cardRef}
              className="w-[340px] h-[214px] rounded-2xl overflow-hidden shadow-2xl relative bg-white text-ink"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              {side === "front" ? (
                <>
                  <div className="h-14 flex items-center px-4" style={{ background: tpl.color }}>
                    <p className="text-white font-bold text-sm truncate">{org}</p>
                  </div>
                  <div className="flex gap-4 p-4">
                    <div className="w-20 h-24 rounded-lg bg-gray-100 border border-gray-200 overflow-hidden flex items-center justify-center shrink-0">
                      {photo ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={photo} alt="ID" className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-[10px] text-gray-400">Photo</span>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm truncate">{name}</p>
                      <p className="text-xs text-gray-500 truncate">{role}</p>
                      <p className="text-xs mt-2" style={{ color: tpl.color }}>ID: {idNumber}</p>
                      <p className="text-[10px] text-gray-400 mt-1">Valid till {validTill}</p>
                    </div>
                    {qrDataUrl && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={qrDataUrl} alt="QR" className="w-12 h-12 shrink-0" />
                    )}
                  </div>
                </>
              ) : (
                <div className="p-5 h-full flex flex-col justify-between">
                  <p className="text-[11px] text-gray-600 whitespace-pre-line leading-relaxed">{backText}</p>
                  <div className="h-2 w-full rounded-full" style={{ background: tpl.color }} />
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-center gap-3 mt-5">
            <button onClick={downloadPng} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold gradient-primary text-white hover:opacity-90 transition-opacity text-sm">
              <Download size={16} /> Download PNG
            </button>
            <button onClick={() => window.print()} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold bg-white/5 hover:bg-white/10 text-fg transition-colors text-sm">
              <Printer size={16} /> Print
            </button>
          </div>
        </div>
      </div>

      {toast && (
        <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 glass px-5 py-3 rounded-xl shadow-xl text-sm text-fg flex items-center gap-2 animate-fade-up">
          {toast}
          <button onClick={() => setToast(null)}><X size={14} /></button>
        </div>
      )}
    </div>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="text-xs text-fg/50 block">
      {label}
      <input value={value} onChange={(e) => onChange(e.target.value)} className="w-full mt-1 bg-transparent border border-white/15 rounded-lg px-3 py-2 text-fg text-sm" />
    </label>
  );
}

export default function IdCardMakerPage() {
  return (
    <Suspense fallback={<div className="max-w-6xl mx-auto px-4 py-20 text-center text-fg/50">Loading...</div>}>
      <IdCardInner />
    </Suspense>
  );
}
