import type { Metadata, Viewport } from "next";
import { Inter, Manrope } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import MobileNav from "@/components/MobileNav";
import WelcomeIntro from "@/components/WelcomeIntro";
import { ThemeProvider } from "@/components/ThemeProvider";

const inter = Inter({ variable: "--font-inter", subsets: ["latin"], display: "swap" });
const manrope = Manrope({ variable: "--font-manrope", subsets: ["latin"], display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL("https://srivenkateshwaraonlinemaker.com"),
  title: {
    default: "Sri Venkateshwara Online Maker — Create. Convert. Design. Print.",
    template: "%s | Sri Venkateshwara Online Maker",
  },
  description:
    "Your complete digital work & printing studio. Passport photo maker, PDF tools, ID card maker, resume builder, design studio and cyber cafe workflow — all in one premium platform built for India.",
  keywords: [
    "passport photo maker",
    "passport photo pdf",
    "image to pdf",
    "pdf tools",
    "photo resize",
    "id card maker",
    "resume maker",
    "cyber cafe tools",
    "online print tools",
  ],
  openGraph: {
    title: "Sri Venkateshwara Online Maker",
    description: "Create. Convert. Design. Print. Everything you need for your digital work — in one place.",
    url: "https://srivenkateshwaraonlinemaker.com",
    siteName: "Sri Venkateshwara Online Maker",
    locale: "en_IN",
    type: "website",
  },
  manifest: "/manifest.json",
  icons: {
    icon: "/favicon.svg",
    apple: "/favicon.svg",
  },
};

export const viewport: Viewport = {
  themeColor: "#0B1020",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} ${manrope.variable} antialiased min-h-screen flex flex-col`}>
        <ThemeProvider>
          <WelcomeIntro />
          <Navbar />
          <main className="flex-1 pb-16 md:pb-0">{children}</main>
          <Footer />
          <MobileNav />
        </ThemeProvider>
      </body>
    </html>
  );
}
