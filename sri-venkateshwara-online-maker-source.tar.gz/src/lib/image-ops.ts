// Client-side image processing helpers — canvas based, no server round trip.

export interface Adjustments {
  brightness: number; // -100..100
  contrast: number; // -100..100
  saturation: number; // -100..100
  sharpen: boolean;
  rotate: number; // degrees
  bgColor: string | null; // hex or null (transparent/original)
  borderWidth: number; // px at output resolution
  borderColor: string;
}

export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

/**
 * Renders a cropped + adjusted photo onto a canvas of exact target pixel size,
 * applying zoom/pan crop box, rotation, color adjustments, background fill and border.
 */
export async function renderPassportPhoto(params: {
  imageSrc: string;
  outWidthPx: number;
  outHeightPx: number;
  crop: { x: number; y: number; width: number; height: number }; // in source image px
  adjustments: Adjustments;
}): Promise<string> {
  const { imageSrc, outWidthPx, outHeightPx, crop, adjustments } = params;
  const img = await loadImage(imageSrc);

  const canvas = document.createElement("canvas");
  canvas.width = outWidthPx;
  canvas.height = outHeightPx;
  const ctx = canvas.getContext("2d")!;

  // background fill first (in case of transparent PNG or border padding)
  ctx.fillStyle = adjustments.bgColor ?? "#FFFFFF";
  ctx.fillRect(0, 0, outWidthPx, outHeightPx);

  ctx.save();
  ctx.translate(outWidthPx / 2, outHeightPx / 2);
  ctx.rotate((adjustments.rotate * Math.PI) / 180);
  ctx.filter = `brightness(${100 + adjustments.brightness}%) contrast(${100 + adjustments.contrast}%) saturate(${100 + adjustments.saturation}%)`;

  const bw = adjustments.borderWidth;
  const drawW = outWidthPx - bw * 2;
  const drawH = outHeightPx - bw * 2;

  ctx.drawImage(
    img,
    crop.x,
    crop.y,
    crop.width,
    crop.height,
    -drawW / 2,
    -drawH / 2,
    drawW,
    drawH
  );
  ctx.restore();

  if (adjustments.sharpen) {
    applySharpen(ctx, outWidthPx, outHeightPx);
  }

  if (bw > 0) {
    ctx.strokeStyle = adjustments.borderColor;
    ctx.lineWidth = bw;
    ctx.strokeRect(bw / 2, bw / 2, outWidthPx - bw, outHeightPx - bw);
  }

  return canvas.toDataURL("image/png");
}

function applySharpen(ctx: CanvasRenderingContext2D, w: number, h: number) {
  const weights = [0, -1, 0, -1, 5, -1, 0, -1, 0];
  const src = ctx.getImageData(0, 0, w, h);
  const dst = ctx.createImageData(w, h);
  const sd = src.data;
  const dd = dst.data;
  const side = 3;
  const halfSide = 1;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const dstOff = (y * w + x) * 4;
      let r = 0, g = 0, b = 0;
      for (let cy = 0; cy < side; cy++) {
        for (let cx = 0; cx < side; cx++) {
          const scy = Math.min(h - 1, Math.max(0, y + cy - halfSide));
          const scx = Math.min(w - 1, Math.max(0, x + cx - halfSide));
          const srcOff = (scy * w + scx) * 4;
          const wt = weights[cy * side + cx];
          r += sd[srcOff] * wt;
          g += sd[srcOff + 1] * wt;
          b += sd[srcOff + 2] * wt;
        }
      }
      dd[dstOff] = Math.min(255, Math.max(0, r));
      dd[dstOff + 1] = Math.min(255, Math.max(0, g));
      dd[dstOff + 2] = Math.min(255, Math.max(0, b));
      dd[dstOff + 3] = sd[dstOff + 3];
    }
  }
  ctx.putImageData(dst, 0, 0);
}

export function dataUrlToBlob(dataUrl: string): Blob {
  const [meta, b64] = dataUrl.split(",");
  const mime = meta.match(/:(.*?);/)?.[1] ?? "image/png";
  const bin = atob(b64);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new Blob([arr], { type: mime });
}
