export interface ToolDef {
  id: string;
  name: string;
  description: string;
  href: string;
  category: "photo" | "pdf" | "idcard" | "document" | "design" | "qr" | "scanner" | "cybercafe";
  icon: string; // lucide icon name
  status: "live" | "planned";
  popular?: boolean;
}

export const TOOLS: ToolDef[] = [
  // Photo tools
  { id: "passport-photo-pdf", name: "Passport Photo PDF Generator", description: "Upload, crop, and print passport photos on one A4 sheet with exact mm/DPI accuracy.", href: "/passport-photo-pdf", category: "photo", icon: "IdCard", status: "live", popular: true },
  { id: "photo-resize", name: "Photo Resize", description: "Resize any photo to exact pixel, mm, or inch dimensions instantly.", href: "/photo-resize", category: "photo", icon: "Maximize2", status: "live", popular: true },
  { id: "photo-crop", name: "Photo Crop", description: "Crop photos manually or to standard aspect ratios.", href: "/photo-resize?mode=crop", category: "photo", icon: "Crop", status: "live" },
  { id: "photo-compress", name: "Photo Compress", description: "Reduce image file size while preserving visual quality.", href: "/photo-resize?mode=compress", category: "photo", icon: "FileArchive", status: "live" },
  { id: "photo-enhance", name: "Photo Enhance", description: "Sharpen, brighten and correct colors automatically.", href: "/photo-resize?mode=enhance", category: "photo", icon: "Sparkles", status: "planned" },
  { id: "bg-remove", name: "Background Remove", description: "Remove photo backgrounds cleanly with AI assistance.", href: "/background-remove", category: "photo", icon: "Eraser", status: "planned" },
  { id: "bg-color", name: "Background Color Changer", description: "Replace photo background with a solid studio color.", href: "/background-remove?mode=color", category: "photo", icon: "PaintBucket", status: "planned" },
  { id: "signature-crop", name: "Signature Cropper", description: "Extract a clean signature from any scanned page.", href: "/signature-tools", category: "photo", icon: "PenTool", status: "planned" },
  { id: "signature-clean", name: "Signature Cleaner", description: "Remove background noise and smudges from signatures.", href: "/signature-tools?mode=clean", category: "photo", icon: "Wand2", status: "planned" },
  { id: "photo-sheet", name: "4×6 Print Sheet Maker", description: "Arrange multiple photos onto a 4×6 print-ready sheet.", href: "/passport-photo-pdf", category: "photo", icon: "LayoutGrid", status: "live" },
  { id: "bulk-resize", name: "Bulk Photo Resize", description: "Resize many photos at once to the same dimensions.", href: "/photo-resize?mode=bulk", category: "photo", icon: "Images", status: "planned" },
  { id: "bulk-rename", name: "Bulk Photo Rename", description: "Rename a batch of photos using a naming pattern.", href: "/photo-resize?mode=rename", category: "photo", icon: "TextCursorInput", status: "planned" },

  // PDF tools
  { id: "image-to-pdf", name: "Image to PDF", description: "Convert JPG, PNG or WEBP photos into a single PDF document.", href: "/pdf-tools/image-to-pdf", category: "pdf", icon: "FileImage", status: "live", popular: true },
  { id: "merge-pdf", name: "Merge PDF", description: "Combine multiple PDF files into one document in your chosen order.", href: "/pdf-tools/merge", category: "pdf", icon: "Combine", status: "live", popular: true },
  { id: "split-pdf", name: "Split PDF", description: "Extract or separate pages from a PDF file.", href: "/pdf-tools/split", category: "pdf", icon: "Scissors", status: "live" },
  { id: "compress-pdf", name: "Compress PDF", description: "Shrink PDF file size for easy sharing and upload.", href: "/pdf-tools/compress", category: "pdf", icon: "FileDown", status: "planned" },
  { id: "pdf-to-jpg", name: "PDF to JPG", description: "Convert every PDF page into a high-quality JPG image.", href: "/pdf-tools/pdf-to-image", category: "pdf", icon: "FileOutput", status: "live" },
  { id: "reorder-pdf", name: "Reorder / Rotate Pages", description: "Drag to reorder, rotate or delete PDF pages visually.", href: "/pdf-tools/split", category: "pdf", icon: "ArrowDownUp", status: "live" },
  { id: "watermark-pdf", name: "PDF Watermark", description: "Stamp a text or logo watermark across every page.", href: "/pdf-tools/watermark", category: "pdf", icon: "StampIcon", status: "planned" },
  { id: "protect-pdf", name: "PDF Password Protect", description: "Lock a PDF with a password before sharing.", href: "/pdf-tools/protect", category: "pdf", icon: "Lock", status: "planned" },
  { id: "page-numbers", name: "Add Page Numbers", description: "Insert page numbers in any position and style.", href: "/pdf-tools/page-numbers", category: "pdf", icon: "Hash", status: "planned" },
  { id: "scan-to-pdf", name: "Scan to PDF", description: "Turn phone camera photos of documents into a clean PDF.", href: "/document-scanner", category: "pdf", icon: "ScanLine", status: "live" },

  // ID Card
  { id: "id-card-maker", name: "ID Card Maker", description: "Design front & back ID cards with photo, text, QR and logo.", href: "/id-card-maker", category: "idcard", icon: "BadgeCheck", status: "live", popular: true },
  { id: "school-id", name: "School / College ID", description: "Ready-made templates for student ID cards.", href: "/id-card-maker?template=school", category: "idcard", icon: "GraduationCap", status: "live" },
  { id: "employee-id", name: "Employee ID Card", description: "Professional employee ID card templates.", href: "/id-card-maker?template=employee", category: "idcard", icon: "Briefcase", status: "live" },
  { id: "bulk-id", name: "Bulk ID Card Generator", description: "Upload a CSV and photos to generate many ID cards at once.", href: "/id-card-maker?mode=bulk", category: "idcard", icon: "Users", status: "planned" },

  // Documents
  { id: "resume-maker", name: "Resume Maker", description: "Build a professional, ATS-friendly resume in minutes.", href: "/resume-maker", category: "document", icon: "FileText", status: "live", popular: true },
  { id: "biodata-maker", name: "Marriage Biodata Maker", description: "Create a beautiful marriage biodata with photo.", href: "/resume-maker?type=biodata", category: "document", icon: "Heart", status: "live" },
  { id: "cover-letter", name: "Cover Letter Maker", description: "Write a strong cover letter for any job application.", href: "/resume-maker?type=cover-letter", category: "document", icon: "Mail", status: "live" },
  { id: "invoice-maker", name: "Invoice Maker", description: "Generate clean invoices for your business.", href: "/invoice-maker", category: "document", icon: "Receipt", status: "planned" },
  { id: "leave-letter", name: "Leave Letter Maker", description: "Formal leave application letters, ready to print.", href: "/resume-maker?type=leave-letter", category: "document", icon: "CalendarOff", status: "live" },

  // Design studio
  { id: "poster-maker", name: "Poster Maker", description: "Design shop posters, offers and promotions visually.", href: "/design-studio?template=poster", category: "design", icon: "Image", status: "live" },
  { id: "visiting-card", name: "Visiting Card Maker", description: "Create a professional visiting card in minutes.", href: "/design-studio?template=visiting-card", category: "design", icon: "ContactRound", status: "live" },
  { id: "certificate-maker", name: "Certificate Maker", description: "Design certificates for events, courses and awards.", href: "/design-studio?template=certificate", category: "design", icon: "Award", status: "live" },
  { id: "social-post", name: "Social Media Post Maker", description: "Design Instagram and WhatsApp-ready posts.", href: "/design-studio?template=social", category: "design", icon: "Share2", status: "live" },

  // QR
  { id: "qr-generator", name: "QR Code Generator", description: "Generate QR codes for links, UPI, Wi-Fi, text and contacts.", href: "/qr-generator", category: "qr", icon: "QrCode", status: "live", popular: true },
  { id: "barcode-generator", name: "Barcode Generator", description: "Create standard barcodes for products and inventory.", href: "/qr-generator?mode=barcode", category: "qr", icon: "Barcode", status: "planned" },

  // Scanner
  { id: "document-scanner", name: "Document Scanner", description: "Scan documents with your camera and export as PDF.", href: "/document-scanner", category: "scanner", icon: "ScanLine", status: "live" },

  // Cyber cafe
  { id: "cyber-cafe", name: "Cyber Cafe Workspace", description: "Manage multiple customer print jobs with a live queue.", href: "/cyber-cafe", category: "cybercafe", icon: "MonitorSmartphone", status: "live" },
];

export const CATEGORY_LABELS: Record<ToolDef["category"], string> = {
  photo: "Photo Tools",
  pdf: "PDF Toolkit",
  idcard: "ID Card / PVC Tools",
  document: "Document Tools",
  design: "Design Studio",
  qr: "QR & Barcode Tools",
  scanner: "Document Scanner",
  cybercafe: "Cyber Cafe Mode",
};

export function searchTools(query: string): ToolDef[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  return TOOLS.filter(
    (t) =>
      t.name.toLowerCase().includes(q) ||
      t.description.toLowerCase().includes(q) ||
      t.category.toLowerCase().includes(q)
  ).slice(0, 8);
}
