// Sri Venkateshwara Online Maker — Print Layout Engine
// Handles physical-unit <-> pixel conversion, sheet layout math, and PDF-accurate placement.

export type Unit = "mm" | "cm" | "inch" | "px";

export const MM_PER_INCH = 25.4;

export function toMM(value: number, unit: Unit, dpi: number): number {
  switch (unit) {
    case "mm":
      return value;
    case "cm":
      return value * 10;
    case "inch":
      return value * MM_PER_INCH;
    case "px":
      return (value / dpi) * MM_PER_INCH;
  }
}

export function mmToPx(mm: number, dpi: number): number {
  return Math.round((mm / MM_PER_INCH) * dpi);
}

export function pxToMM(px: number, dpi: number): number {
  return (px / dpi) * MM_PER_INCH;
}

export interface PaperPreset {
  id: string;
  label: string;
  widthMM: number;
  heightMM: number;
}

export const PAPER_PRESETS: PaperPreset[] = [
  { id: "a4", label: "A4 (210 × 297 mm)", widthMM: 210, heightMM: 297 },
  { id: "a5", label: "A5 (148 × 210 mm)", widthMM: 148, heightMM: 210 },
  { id: "4x6", label: "4 × 6 inch", widthMM: 101.6, heightMM: 152.4 },
  { id: "5x7", label: "5 × 7 inch", widthMM: 127, heightMM: 177.8 },
  { id: "letter", label: "Letter (8.5 × 11 in)", widthMM: 215.9, heightMM: 279.4 },
  { id: "custom", label: "Custom size", widthMM: 210, heightMM: 297 },
];

export interface PhotoPreset {
  id: string;
  label: string;
  widthMM: number;
  heightMM: number;
}

export const PHOTO_PRESETS: PhotoPreset[] = [
  { id: "india-35x45", label: "India Passport 35 × 45 mm", widthMM: 35, heightMM: 45 },
  { id: "2x2in", label: "US 2 × 2 inch (51 × 51 mm)", widthMM: 50.8, heightMM: 50.8 },
  { id: "pan-25x35", label: "PAN Card 25 × 35 mm", widthMM: 25, heightMM: 35 },
  { id: "stamp-20x25", label: "Stamp Size 20 × 25 mm", widthMM: 20, heightMM: 25 },
  { id: "custom", label: "Custom size", widthMM: 35, heightMM: 45 },
];

export interface SheetItem {
  id: string;
  label: string; // e.g. customer name
  copies: number;
  imageDataUrl: string;
  widthMM: number;
  heightMM: number;
}

export interface LayoutConfig {
  paperWidthMM: number;
  paperHeightMM: number;
  marginTopMM: number;
  marginBottomMM: number;
  marginLeftMM: number;
  marginRightMM: number;
  gapHMM: number;
  gapVMM: number;
  dpi: number;
}

export interface PlacedPhoto {
  itemId: string;
  imageDataUrl: string;
  xMM: number;
  yMM: number;
  widthMM: number;
  heightMM: number;
}

export interface SheetPage {
  photos: PlacedPhoto[];
}

/**
 * Auto-arranges a queue of items (each possibly with different photo size and
 * copy count) into one or more printable sheet pages using simple shelf packing,
 * always keeping physical mm dimensions exact.
 */
export function packSheets(items: SheetItem[], cfg: LayoutConfig): SheetPage[] {
  const pages: SheetPage[] = [];
  const usableWidth = cfg.paperWidthMM - cfg.marginLeftMM - cfg.marginRightMM;
  const usableHeight = cfg.paperHeightMM - cfg.marginTopMM - cfg.marginBottomMM;

  // Flatten queue into individual photo instances (customer order preserved)
  const instances: { itemId: string; imageDataUrl: string; widthMM: number; heightMM: number }[] = [];
  for (const item of items) {
    for (let i = 0; i < Math.max(1, item.copies); i++) {
      instances.push({
        itemId: item.id,
        imageDataUrl: item.imageDataUrl,
        widthMM: item.widthMM,
        heightMM: item.heightMM,
      });
    }
  }

  let cursorX = 0;
  let cursorY = 0;
  let rowHeight = 0;
  let currentPhotos: PlacedPhoto[] = [];

  const commitPage = () => {
    if (currentPhotos.length > 0) {
      pages.push({ photos: currentPhotos });
      currentPhotos = [];
    }
    cursorX = 0;
    cursorY = 0;
    rowHeight = 0;
  };

  for (const inst of instances) {
    // wrap to next row
    if (cursorX + inst.widthMM > usableWidth) {
      cursorX = 0;
      cursorY += rowHeight + cfg.gapVMM;
      rowHeight = 0;
    }
    // wrap to next page
    if (cursorY + inst.heightMM > usableHeight) {
      commitPage();
    }
    currentPhotos.push({
      itemId: inst.itemId,
      imageDataUrl: inst.imageDataUrl,
      xMM: cfg.marginLeftMM + cursorX,
      yMM: cfg.marginTopMM + cursorY,
      widthMM: inst.widthMM,
      heightMM: inst.heightMM,
    });
    cursorX += inst.widthMM + cfg.gapHMM;
    rowHeight = Math.max(rowHeight, inst.heightMM);
  }
  commitPage();

  return pages;
}

export function computeGridCapacity(
  paperWidthMM: number,
  paperHeightMM: number,
  photoWidthMM: number,
  photoHeightMM: number,
  margins: { top: number; bottom: number; left: number; right: number },
  gapH: number,
  gapV: number
): { cols: number; rows: number; total: number } {
  const usableWidth = paperWidthMM - margins.left - margins.right;
  const usableHeight = paperHeightMM - margins.top - margins.bottom;
  const cols = Math.max(1, Math.floor((usableWidth + gapH) / (photoWidthMM + gapH)));
  const rows = Math.max(1, Math.floor((usableHeight + gapV) / (photoHeightMM + gapV)));
  return { cols, rows, total: cols * rows };
}
