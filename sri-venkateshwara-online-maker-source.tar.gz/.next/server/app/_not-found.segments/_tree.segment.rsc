:HL["/_next/static/chunks/1ebuum08psf0g.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4112,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"v5fhqw7_IW8EelQcpdEG3"}
