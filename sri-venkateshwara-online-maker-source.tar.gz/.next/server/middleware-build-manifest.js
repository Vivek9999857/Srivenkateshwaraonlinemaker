globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/v5fhqw7_IW8EelQcpdEG3/_buildManifest.js",
    "static/v5fhqw7_IW8EelQcpdEG3/_ssgManifest.js",
    "static/v5fhqw7_IW8EelQcpdEG3/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1jexzsn2qdw84.js",
    "static/chunks/1ey0h8xsfa_wx.js",
    "static/chunks/3n5xajc_2ez6x.js",
    "static/chunks/3iubgmi2mrvio.js",
    "static/chunks/turbopack-1o_kn-tbufig7.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
