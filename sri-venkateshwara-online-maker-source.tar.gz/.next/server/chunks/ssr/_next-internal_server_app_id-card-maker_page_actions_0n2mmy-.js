module.exports=[779653,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_id-card-maker_page_actions_0n2mmy-.js.map