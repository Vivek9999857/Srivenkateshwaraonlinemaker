module.exports=[105971,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_pdf-tools_pdf-to-image_page_actions_0sp5saw.js.map