module.exports=[286987,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_document-scanner_page_actions_0cmugz6.js.map