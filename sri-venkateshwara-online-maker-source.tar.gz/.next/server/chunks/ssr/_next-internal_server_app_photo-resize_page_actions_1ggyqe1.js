module.exports=[20016,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_photo-resize_page_actions_1ggyqe1.js.map