module.exports=[835409,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_cyber-cafe_page_actions_16len3n.js.map