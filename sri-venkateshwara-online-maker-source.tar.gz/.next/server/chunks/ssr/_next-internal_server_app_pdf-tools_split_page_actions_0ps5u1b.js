module.exports=[336852,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_pdf-tools_split_page_actions_0ps5u1b.js.map