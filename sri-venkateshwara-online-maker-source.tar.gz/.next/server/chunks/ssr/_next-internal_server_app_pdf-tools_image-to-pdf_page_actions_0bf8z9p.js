module.exports=[764396,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_pdf-tools_image-to-pdf_page_actions_0bf8z9p.js.map