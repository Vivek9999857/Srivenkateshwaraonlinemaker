module.exports=[942452,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_design-studio_page_actions_0ilcmnj.js.map